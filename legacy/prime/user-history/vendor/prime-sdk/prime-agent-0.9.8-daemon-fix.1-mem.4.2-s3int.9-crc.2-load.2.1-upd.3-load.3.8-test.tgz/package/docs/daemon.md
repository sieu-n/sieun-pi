# Daemon Architecture

Prime Agent isolates each active root session tree in its own process. The daemon is internal infrastructure: interactive, print, JSON, RPC, piped-stdin, and `--no-session` describe client behavior and retain their public I/O contracts.

## Process Topology

```mermaid
flowchart TD
    clients["Interactive · print · JSON · RPC clients"]
    supervisor["Detached supervisor"]
    catalog["Catalog subprocess<br/>saved-session scans"]
    residentA["Resident worker<br/>root A · RLM descendants · kernels"]
    residentB["Resident worker<br/>root B · RLM descendants · kernels"]
    owned["Client-owned worker<br/>hidden root · RLM descendants · kernels"]

    clients <-->|"public local protocol"| supervisor
    supervisor --> catalog
    supervisor --> residentA
    supervisor --> residentB
    supervisor --> owned
```

The supervisor owns public sockets, client attachments, routing, global agent-message delivery, worker health, command journals, and coordinated updates. It does not execute providers, tools, compaction, bash, kernels, schedules, or transcript scans.

The catalog subprocess owns saved-session scans and inactive-session file operations. A catalog failure can fail a catalog request without interrupting active workers.

Each worker owns one root `AgentSessionRuntime`, its root `AgentSession`, scheduler, kernels, and every RLM descendant below that root. New, switch, fork, and import operations replace the root runtime inside the worker while preserving the public active-session ID.

## Resident Workers

Normal interactive sessions use resident workers:

- The supervisor starts one detached process group per active root tree.
- Closing the TUI detaches the client; it does not stop the worker.
- Worker descriptors, authentication tokens, active-session IDs, session paths, and recovery journals are written with owner-only permissions under the agent directory.
- Workers monitor the public supervisor socket. If it disappears, one worker acquires an atomic launch lease and starts a replacement supervisor.
- When `PRIME_AGENT_DAEMON_LAUNCH_COMMAND` is set and `PRIME_AGENT_DAEMON_LAUNCH_FOR_SOCKET` names the socket, an interactive client or a worker that needs a supervisor on that socket runs the command through `/bin/sh -c` with the socket in `PRIME_AGENT_DAEMON_LAUNCH_SOCKET`, instead of spawning the supervisor as its own child. A service manager that owns the daemon sets both, so the supervisor starts in the service and not in the caller's process group or cgroup. Supervisors and the update restart coordinator never run the command. A failing command is an error, and Prime does not start a supervisor itself instead.
- A replacement supervisor adopts live workers and their active-session IDs.
- A worker crash affects one root tree. Recovery retries after 250 ms, 1 second, and 5 seconds; three failures mark that root failed.
- A resident root whose worker died is relaunched from its saved session file under the supervisor's environment, with no client needed.
- `prime-agent shutdown` stops the supervisor and all workers; `--force` also terminates unresponsive worker process groups and tracked children.
- `prime-agent shutdown --daemon-socket <path>` stops only the daemon on that socket and reads no worker descriptors from the agent dir.
- The supervisor refuses `shutdown` and `restart` from an agent session it runs, unless the shutdown ends a prepared update restart. It knows such a caller by the peer pid, from `SO_PEERCRED` on Linux and `LOCAL_PEERPID` on macOS: the peer or an ancestor is one of its workers, has `PRIME_AGENT_INTERNAL_DAEMON_SUPERVISOR_SOCKET` set to its socket, or has `RLM_SESSION_DIR` inside its agent dir. A caller the kernel does not name, or one that exits before the check, is refused too. Windows pipes have no peer read, so Windows skips this check. `prime-agent shutdown --force` reports such a refusal and never kills that daemon or its workers in its place. Every `shutdown`, `restart` and `prepare_update_restart` request writes one `stop_request` line with the peer to the supervisor log and `<socket>.<hash>.calls.jsonl` before teardown.

There is no fixed session, worker, client, or workload cap in this layer.

## Client-Owned Workers

Headless and ephemeral clients use the same worker runtime as interactive clients but give the worker a client-owned lifecycle:

- print, piped stdin, and JSON mode remain one-shot;
- RPC keeps LF-delimited JSONL framing and accepts prompts until EOF;
- interactive `--no-session` uses an in-memory session;
- normal completion explicitly removes the worker without archiving it;
- unexpected client loss starts a bounded cleanup grace period;
- reconnect with the same stable client identity cancels cleanup; and
- default lists, global schedules, and peer routing omit client-owned workers unless the owner explicitly addresses them.

The full launch environment remains in supervisor memory and is not written to the worker descriptor. Direct SDK calls to print and RPC modes remain in-process so embedders can pass non-serializable extension factories.

## Session Ownership and Leases

Every persisted session is protected by a process-safe lease keyed by canonical JSONL path.

- A worker acquires a target lease before opening a session.
- Runtime replacement acquires the new lease before releasing the old one.
- Concurrent opens return `session_already_active` with the owning active-session ID.
- Concurrent creates for the same path converge on one worker launch.

This prevents daemon workers and one-shot clients from writing the same transcript concurrently.

## Scheduling

Each worker runs one scheduler for its root and descendants. Jobs are persisted per session in `session-artifacts/<session-id>/scheduled-jobs.json`; workers do not share a global cron file.

Due ticks are claimed and advanced before prompt delivery. A crash therefore does not replay an uncertain prompt. Different target sessions dispatch independently, and a still-active claim coalesces later missed ticks instead of building an unbounded backlog.

Resident workers keep scheduling across supervisor replacement. Worker recovery marks uncertain claims interrupted, keeps the advanced schedule, and resumes future ticks only. The supervisor routes schedule commands and merges worker summaries for global listing.

## Public Daemon Protocol v4

The public local socket is JSONL-framed. The current protocol provides:

- versioned command envelopes with stable client and command IDs;
- capability negotiation and per-command compatibility metadata;
- generation-aware event cursors `{ generation, sequence }`;
- reconnect with a stable identity and resume cursor;
- attach acknowledgment plus coherent snapshots;
- begin/chunk/end snapshot streaming with a 512 KiB target chunk size;
- file-backed transcript caches above 4 MiB;
- resident and client-owned worker lifecycle commands;
- daemon-side headless completion, session-header, bash, and retry operations; and
- structured errors for recoverable cases such as an already-active session or uncertain mutation result.

Protocol version and schema revision are independent. A compatible addition can be capability-gated or require a schema revision; an incompatible wire change requires a protocol bump.

Protocol v1 is retained only for the one-release update handoff that prepares and stops an older daemon. A busy older daemon that cannot produce a recovery manifest is left running.

JSON and RPC client modes do not expose daemon greetings, envelopes, snapshot records, lifecycle events, or connection metadata.

## Reconnect, Replay, and Snapshots

Every sequenced event belongs to a worker generation. Clients retain the last `{ generation, sequence }` cursor and present it on attach. The server reports whether the requested interval is complete, partial, or unavailable.

A generation change invalidates comparison with the old sequence. Missing replay is not fatal: the attach snapshot is the durable recovery baseline. `DaemonAgentConnection` applies the snapshot, ignores duplicate or retired-generation events, and reports a resynchronized session to the UI.

Large snapshots are encoded in the worker and streamed as opaque chunks through a bounded supervisor cache. The supervisor never constructs a history-sized object.

## Private Worker Transport

Supervisor-worker traffic uses a binary frame:

```text
4-byte JSON header length
4-byte payload length
small JSON routing header
opaque payload bytes
```

Workers serialize a public event once. The supervisor reads only the routing header and forwards the same payload buffer to eligible clients.

Assistant streaming uses compact start/delta/end payloads privately. The supervisor reconstructs the existing public `message_update` once per delta, so the full growing assistant message is not repeatedly transferred from worker to supervisor.

Private worker connections authenticate with per-worker tokens and are fenced to the current supervisor generation. This prevents an obsolete replacement supervisor from continuing to command an adopted worker. It is process coordination, not a sandbox boundary: all processes still run as the same OS user.

## Backpressure

Backpressure is attachment-local:

- a blocked client stops receiving incremental events;
- other clients and workers continue;
- the supervisor retains no unbounded per-client queue; and
- after drain, the attachment catches up from its cursor or receives a fresh snapshot.

Final transcript caching is separate from live partial-message reconstruction.

## Idempotency and Crash Recovery

Mutating commands are keyed by `clientId + commandId` and recorded before dispatch in an append-only journal.

- Repeating a completed command returns the stored result.
- A received command without a durable result is reported as uncertain and is not replayed.
- Reconnect retains the same command ID.
- Clients acknowledge completed mutations so journal entries can be compacted.

Workers journal operation transitions and detached subprocess identities. After a worker crash, recovery reaps its old process group and tracked detached bash trees, appends a visible recovery marker to the transcript, restores the root under the same active-session ID, and does not replay uncertain side effects.

Accepted input survives a worker crash and a daemon shutdown:

- A worker writes every unfinished steer, follow-up, agent message and prompt to `session-artifacts/<session>/accepted-input.json` before it answers the command. This includes a child's first task: `rlm.spawn` returns only after that task is in the child's file.
- Each record holds the action's operation id and one state. Completion of the action removes the record.

| State | Meaning | Written when |
| --- | --- | --- |
| `accepted` | Still queued. | Admission, before the ack. |
| `dequeued` | Left the queue, not yet in a run. | Selection. |
| `delivered` | Its message started in a run. | `message_start` of the message. |
| `consumed` | The model called tools for it. The record lists `toolNames`. | `message_end` of the tool call, before any tool runs. |
| `completed` | The model gave a final reply. | `message_end` of the reply. |

- A relaunched or reopened worker sorts each record into one outcome:
  - Completed: the state is `completed`, or the transcript holds a final reply after the message. It is never run again.
  - Uncertain: the state is `consumed`, or the transcript holds a tool call or tool result after the message and no final reply. A tool may have changed something outside the transcript, so the input is never run again.
  - Redelivered: anything else. No model output follows the message, so the turn was held in a context hook, such as a pool slot wait, or cut in its model call. It is admitted again, in the visible queue, with its operation id. A turn that was already running goes first, so the input that waited to join it still follows it. If the transcript already holds the cut message, the redelivery adds one more copy.
- An aborted or failed model reply with no tool call counts as no output.
- The worker writes one `prime-agent.accepted_input_recovery` entry with `deliveredBeforeStop` (completed operation ids), `redelivered` (operation ids), `redeliveredInputIds` (their agent message ids) and `uncertain` (`{ operationId, inputId?, toolNames }` per input). A resend of a completed or uncertain operation id is answered and not run. A tool that continues lost input must skip every id named in the entry, and must never continue an uncertain one by itself.
- When a worker opens a root session, it also reopens each child of that root whose file still holds records, so a child's held task runs once without a message to the child.
- An owner stop is kept: recovered input waits for a resume.
- A daemon shutdown keeps the file, and the next open of the session delivers it. An owner stop, kill, archive, delete or update close removes it.
- Archiving a saved session with any reason except `idle_unload`, `daemon_shutdown` or `update_discarded` removes the file too, also when the worker had archived the session itself before it died. Deleting a session removes its artifact directory, file included.

`rlm.spawn` raises when the child's runtime fails to start or its first task is refused, or when the child is deleted before its task is admitted. The parent gets no `rlm_child_failure` notice for that spawn, and the name is free again.

The supervisor gives steer, follow_up, send_message and prompt the operation id `[clientId, commandId]`. A worker admits one action per operation id. A resent prompt it already holds is answered before any prompt work, so the resend never resumes a queue the owner stopped. A failed input command keeps no journal result. A resend of one without a stored result, including one an earlier supervisor received, is dispatched again only when the target worker advertised `operation_id_dedupe` in its `worker_auth` answer. A worker from an older build, adopted after a supervisor update, does not advertise it, so the resend is answered `command_result_uncertain` and never reaches that worker.

## Coordinated Updates

Update preparation is two-phase:

1. Resident workers create non-destructive checkpoints in parallel.
2. The supervisor validates and atomically persists the aggregate manifest.
3. Only after every prepare succeeds does it commit and stop workers.

If preparation or manifest validation fails, prepared workers are released and all roots continue running.

## Benchmarks

From `packages/coding-agent`:

```sh
npx tsx test/daemon-multiclient-bench.ts
npx tsx test/daemon-multiclient-bench.ts --generated-session-mib 100
npx tsx test/daemon-multiclient-bench.ts --generated-session-mib 500
npx tsx test/daemon-multiclient-bench.ts --session-file /path/to/session.jsonl
PRIME_AGENT_STRESS_WORKERS=50 npx tsx ../../node_modules/vitest/dist/cli.js --run test/daemon-supervisor-process.test.ts -t "hosts resident roots"
```

The benchmark compares fanout and attach paths, including serialization count, throughput, elapsed time, and sampled RSS. The stress case starts many resident roots and verifies that their schedules advance independently while sessions are busy.
