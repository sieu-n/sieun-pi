# Changelog

## [0.9.8] - 2026-09-29

- Fixed Codex subscription model discovery to claim the current stable Codex CLI release (0.159.0, up from 0.153.4): ChatGPT gates the discovery endpoint on `client_version`, and the stale pin hid GPT-6 Sol and Luna from `rlm` subagent delegation and `find_models()` while the `/model` picker kept offering them ([#2544](https://github.com/PrimeIntellect-ai/prime-agent/discussions/2544)).
- Fixed the model picker showing a stale model list for up to a minute when opened without a search term (Ctrl+L or plain `/model`); it now always refreshes the catalog on open ([#2504](https://github.com/PrimeIntellect-ai/prime-agent/pull/2504) by [@sirouk](https://github.com/sirouk)).

## [0.9.7] - 2026-09-28

- Changed the continual-harness kernel surface back to the twelve per-kind CRUD methods on `rlm.harness` (`create_memory`/`update_memory`/`delete_memory` plus the `*_skill`, `*_subagent`, and `*_prompt_note` methods), the `path` spelling of the harness entry grouping, and callable `rlm.harness.record_refinement`/`plan_refinement`, reverting #2154 and #2155 at the user's request.
- Fixed harness state persisted while the grouping was spelled `topic` losing that grouping after the revert: entries migrate to `path` when they load, and rolling back a refinement recorded in that window restores the entry's original grouping.
- Fixed the conversation detail level resetting to Details every time you open, resume, or attach to a chat: the level you pick with Ctrl+O is now saved as the `chatDetail` setting and reused for every chat until you change it. Chats with no saved choice still start at Details.
- Fixed Option+S not toggling the model selector scope on macOS terminals that type `ß` instead of sending Option as Meta; the character no longer lands in the search field.
- Fixed old sessions showing as running in the agents view as soon as you open them, even though nothing is running: a session now counts as running only while it is doing work, not while its status summary is out of date.
- Fixed host stalls while a kernel cell sends a multi-megabyte display output (such as a large image) or host request: the host now reads kernel output in linear time instead of rescanning the partial line on every pipe chunk.
- Changed the daemon to take its supervisor and worker command lists from the protocol command table, and daemon-hosted subagents to take their session options from the same mapping as in-process subagents. No behavior change.
- Removed unused internal code: parameters that every caller set to the same value, a worker message nothing sends, a never-set ACP meta field, five never-set UI component options, a test-only MCP store option, and four test-only helpers.
- Removed unused internal code: the orphaned `core/index.ts` barrel, six uncalled helpers, and eleven unused daemon protocol types.

## [0.9.6] - 2026-09-23

- Added daemon incident notices to the agents view: recent worker crashes, command-timeout bursts, and update restarts surface as a dismissible status line pointing at `prime-agent incident`.
- The Anthropic subscription-auth warning now names the risk: subscription requests identify as Claude Code, which may violate Anthropic's terms and can get the account restricted or banned; an API key avoids the risk.
- Branch summaries now run through the `auxiliaryModel` setting, not just refinement and compaction passes. Branch summarization fires at a tree-navigation context boundary and the summarizer uses its own prompt prefix, so running it on the session model paid full input price at context peak for a one-off call outside the session's cached prefix. The summary falls back to the session model when the setting is unset, unusable, or its context window cannot hold the branch the summary covers plus the reserve the summary call needs.
- Capped the spawning cell source attached to kernel host requests at 2KB with a truncation marker, so oversized cells stop re-shipping their full source on every spawn/progress-note/collect round trip and in each child's persisted spawnCode.
- Changed bundled model and MCP catalog assets to be generated during build and release instead of committed snapshots.
- Added bundled model and MCP catalog snapshots with hourly background refresh and last-good disk caches.
- Compaction summaries now run through the `auxiliaryModel` setting, not just refinement passes. Compaction fires at context peak and the summarizer uses its own prompt prefix (a different system prompt and no tools), so it cannot hit the session's cached prefix: on the session model the summary re-reads its whole input at peak price, plus a one-shot 1.25x cache write on Anthropic-style providers, and on OpenAI-style providers its divergent prefix still rides the session's `prompt_cache_key`, which is the documented way to depress hit rates. Routing through `auxiliaryModel` moves that call off the session model. The summary falls back to the session model when the setting is unset or unusable.
- Compaction summaries no longer request the session's thinking level. Summarizing is transcription rather than reasoning, and with no reasoning requested the summary call stays cheap and cannot trip an invalid reasoning effort on the summary model.
- Context-tree rebuilds (top-bar cost refresh, /context) now reuse a per-file parse cache keyed by file size and mtime instead of re-reading every finished child session on each refresh.
- Cleaned up contract hygiene in the agent family surfaces: `agent_observe` rows now carry the shared family `status` (`running`/`idle`/`inactive`) plus a separate typed live `activity`, the public `turn_end` and `message_update` events are typed as assistant-only, Ctrl+C in the standalone config selector is remappable through the keybinding config, and the daemon revision catalog, agents-view emptiness comment, and `pi-agent` README no longer state facts the code contradicts.
- Fixed quota parks restored after their wake time: a daemon wake or restart now keeps the park count so `retry.provider.waitForUsage.maxParks` still bounds re-parking, and the stale wake job is settled by the resumed session instead of lingering.
- Bumped the daemon schema revision for the structured update-restart error info, so mismatched daemon and CLI builds around that change are detected by the self-update checks.
- Fixed agents-view roster summaries going stale when a session's spawn code changed while every other summary field stayed the same.
- Added `prime-agent incident` to reconstruct daemon incidents from logs into an operator timeline (supervisor events, session anomalies, recovery actions) with `--since`/`--until` window and `--session` filters.
- The daemon supervisor, both daemon clients and the agents view now share the daemon protocol module's response and session-summary guards. The agents view now rejects a session summary that has no working directory instead of accepting it as complete (the daemon has always required it).
- Fixed session switches fetching the full transcript twice: a switch consumes the streamed replacement snapshot instead of refetching, so the history crosses the wire once when switching to a large session, while a switch whose replacement stream fails or never lands still reloads the transcript.
- Fixed a session switch reading a replacement snapshot streamed for another session (an earlier switch's late stream, or another client's switch on the same daemon session) as its own transcript, and made the switch wait end when the connection closes terminally or a re-attach resync delivers the requested session, instead of relaying its timeout.
- Prime Inference login and agent trace uploads now share one set of HTTP helpers (request timeout, error-body parsing, field readers). A Prime Inference request that is still waiting on its timeout no longer keeps the process alive on its own.
- Reduced per-model-request CPU cost by fingerprinting a bounded turn-body subset (model identity, shaping options, system prompt, message count, last message, tool schemas) instead of re-serializing the full request body, with the tool-schema digest memoized per session.
- Reduced event-flood CPU on busy workers: child update previews now collapse only the trailing ~200 chars of the streaming message (O(L²) → O(200) per streamed child message) with per-child update emits capped at ~1/s, roster flushes coalesce into a 250ms window and recompose only trigger-marked sessions (lifecycle mutations still flush everything on the next tick), top-bar cost refreshes from session status are throttled to 1/s (agent_end and attach stay unthrottled), and recap summarizer model calls are capped at 4 concurrent fleet-wide with the most recently active session admitted first.
- Fixed the daemon worker client keeping a stale socket after a failed or timed-out connect, so the next connect attempt on that client threw "already connected" instead of opening a fresh socket.
- Fixed a bridge write into a dead or stopped owned session worker (write EPIPE) crashing the whole CLI frontend: pipe errors are now absorbed so the existing worker close-based recovery (failing pending RPC commands and relaunching) runs instead.
- Fixed RPC commands that arrive while the worker bridge is down being reported failed ("uncertain and was not replayed") and then replayed to the replacement worker anyway: a command is now tracked as pending only once it is actually written to a worker, so buffered commands replay exactly once and commands that reached a dead worker fail exactly once.
- Fixed a worker that closed its stdin read end while staying alive hanging the frontend forever: the absorbed bridge EPIPE now kills the worker so the crash-recovery loop (failure responses, relaunch from the recovery descriptor) runs, and commands that were only buffered are failed when no recovery can replay them.
- Fixed `rlm.delete_subagent` holding a deleted child's session name until its background unwind finished: the name now frees at the delete receipt, so a replacement child can be spawned immediately under the same name.
- Fixed `rlm.collect` throwing `No direct RLM child matches` when a requested target was deleted moments earlier: collect now returns a settled `cancelled` envelope for just-deleted targets immediately, without spending the timeout budget.
- Fixed a daemon-mode respawn under a just-deleted child's name failing the name check: the delete receipt now frees the child's session name in the daemon catalog too — and the daemon host's runtime-boundary re-assert honors the same freed ids the spawn admission forwarded, instead of only the parent session's local run map.
- Fixed `rlm.collect` resolving a reused child name to the previous generation's `cancelled` envelope while the new child's delete was still in preflight: the selector now reports no match until the delete settles.
- Fixed `rlm.collect` throwing `No direct RLM child matches` when a live child's background unwind had already finished before the parent collected it: the accepted delete now leaves a tombstone, so its settled `cancelled` envelope stays addressable by child id and session name until the parent session is disposed.
- Fixed `rlm.collect` for retained children deleted without an active run: a retained completed child or a daemon-hydrated child that never had a run now leaves the same delete tombstone as a live child, so collect answers with the settled `cancelled` envelope its delete receipt promised, and a still-pending run-less delete blocks a reused selector instead of resolving to the previous generation's envelope.
- Fixed `rlm.collect` resolving a reused child name to the previous generation's `cancelled` envelope while a live daemon-hydrated run-less replacement owns the name, including one whose delete failed and left it resident for a retry: the selector now reports no match until that replacement is deleted, matching the existing delete-preflight convention.
- Fixed a Python cell raising an exception with a huge message restarting the kernel through protocol repair: error text and traceback entries are now capped at 1 Mi characters with a truncation marker, like result text, so the error is reported in the cell.
- Fixed an oversized `host_request` payload (for example a huge skill-call argument) tearing the kernel protocol and restarting the kernel: `rlm.host_request()` now raises `ValueError` in the calling cell, like `emit()` does for display payloads.
- Fixed a stale background `bash()` completion notice waking the model after it had already read the finished handle's result in the same turn ([#2372](https://github.com/PrimeIntellect-ai/prime-agent/pull/2372)).
- Fixed kernel startup re-running the Python skill sync and rewriting the venv marker on every session when a skill depended on a sibling skill; such venvs now take the same zero-cost warm-start path as any other synced venv.
- Reduced Python kernel snapshot cost: auto-snapshots serialize each variable exactly once into a length-framed payload instead of a second whole-namespace dump (and no prefix re-dump at the aggregate cap), compaction re-serializes each variable once (bounded by the per-variable cap) and prunes only the ones that still measure oversized, so a value shrunk in place or redefined after an earlier snapshot is never deleted on a stale size, and a resumed kernel skips the auto-snapshot that would rewrite the just-restored namespace until a real cell changes it.
- Changed live Prime Inference catalog refreshes to rebuild each model's thinking levels and reasoning compat from the route's declared parameters, so stale bundled templates no longer override what the gateway actually accepts.
- Fixed the stored Prime team selection being hidden whenever the API key came from a runtime or environment override: an ambient PRIME_API_KEY supplies the key, never the team, so the stored login's team still scopes the credentialed catalog and private-model fetches and team-private internal routes keep appearing in the model picker.
- Fixed Prime Inference team headers having two owners: the provider layer no longer reads `team_id` from the Prime CLI profile (`~/.prime/config.json`), so a runtime or `PRIME_API_KEY` credential that deliberately has no saved Agent team stays team-less instead of inheriting an unrelated CLI team. The agent's auth storage stays the single source for `X-Prime-Team-ID` (saved team or `PRIME_TEAM_ID`).
- Fixed shell-command credentials (`!command` API keys and header values) caching failures forever: a command that resolved to nothing is now retried on the next lookup, so a locked keychain or a transient failure no longer disables the credential for the lifetime of the process.
- Fixed proxy streaming: a truncated response now ends with an error instead of leaving the turn waiting forever, and the service tier setting is now sent through the proxy like it is for direct provider calls.
- Fixed a queued prompt disappearing from the interactive queued-messages area while its own pre-turn compaction runs; it now stays visible there (as a "Starting" entry) until the turn begins.
- Added `/tier` to show or set the session service tier (default, flex, priority, auto), a `Default service tier` row in `/settings` that also applies to the running session, and a footer badge for any non-default tier ([RES-1326](https://linear.app/primeintellect/issue/RES-1326)).
- Folded the twelve per-kind continual-harness CRUD methods into three: `rlm.harness.create_memory(title, content, kind=...)`, `rlm.harness.update_memory(id, title, content, kind=...)`, and `rlm.harness.delete_memory(id, kind=...)`. Prompt notes, skills, and subagent specs are subtypes of memory, so `kind` selects them; it defaults to `memory`, only skill entries accept `reference`/`arguments`, the nine removed names raise an error naming their replacement, and the positional-kind `create`/`update`/`delete` methods are removed as well.
- Renamed the harness entry grouping from `path` to `topic` in the kernel API, the refinement planner schema, and the harness digest; state files written before the rename still load, and saves keep writing the grouping under both names while older builds can still reach the shared global store.
- Removed `rlm.harness.record_refinement` and `plan_refinement` from the model-facing kernel surface. The refinement engine already records an event for every refinement it applies, so the manual call only duplicated those events or added unverified ones. Reading stays unchanged through `rlm.get_harness_state().refinements` and the harness overview; the old name now raises an error explaining that events are recorded automatically.
- Provider retries now add +/-25% jitter to their computed exponential backoff so concurrent sessions spread out during a shared outage instead of retrying in lockstep; server Retry-After waits are still honored exactly.
- Cut redundant broadcast work under streaming and fleet load: the supervisor now compares roster rows against their last published serialization so repair pulls, snapshot applies, and staleness sweeps no longer re-broadcast identical entries to every subscriber; child update dedup compares fields instead of building and serializing a full snapshot per streamed delta (the prompt label is computed once per run); and queue updates serialize the snapshot once instead of twice per mutation.
- Fixed provider safety-filter failures (e.g. content_filter) being auto-retried: they are permanent rejections.
- Stopped fanning supervisor heartbeat lists, scheduled-job wake recomputes, and cron-store mutations out to every worker, client, and artifact path: worker heartbeat snapshots refresh per reporting worker, the wake timer arms from a cached aggregate (a changed stale-while-revalidate refresh re-arms it), heartbeats_changed pushes reach only clients that track heartbeats (by scheduled-job command or the heartbeat_catalog attach capability; daemon-side lookups now also resolve paused and cancelled passive jobs), and cron-store mutations lock just the paths they write with one fsync and non-blocking retries.
- Added `prime-agent sessions`, a one-line-per-agent operator table (status, activity, staleness, last error, usage) rendered client-side from the existing daemon session summaries.
- Runtime extension discovery now applies the same rules as package resource discovery: entries matched by a `.gitignore`, `.ignore` or `.fdignore` file in the extensions directory, dot entries and `node_modules` are skipped, so a directory excluded from package discovery is no longer loaded at runtime.
- Ignore-file parsing, extension entry-point resolution, resource path expansion and path containment checks now each have one implementation instead of two to four copies, so the loaders can no longer drift apart.
- Fixed unclear blocked-update warnings: the refusal now names the blocking session, and the report now says to run `prime-agent shutdown`, then run `prime-agent` to restart and apply the update.
- Fixed `shutdown --force` failing with "Daemon shutdown admission was lost" when slow daemon scans delayed the admission lease refresh.
- Changed agent trace uploads to report every scheduled upload and retry wait, and to expose when the startup catch-up and in-flight uploads have finished.
- Added `PRIME_AGENT_PROBE_TIMEOUT_SECONDS` so an install can override the executable probe deadline that otherwise defaults to 60 seconds.
- Changed the daemon worker supervisor monitor to report when each availability check settles, so its recovery behavior is observable instead of timing-dependent.
- Fixed inline pickers drawing two stacked separator rules when an empty placeholder child preceded the search box, which also cost the list a visible row.
- The per-service accounts menu (open /mcp and select a connected service) is rebuilt as a static choice list in the onboarding-choice visual language: "Accounts — Cloudflare" became "Cloudflare MCP" with the service description moved above the options (muted, wrapped, capped at three lines), the no-op search box and the account-name row are gone, and the rows are `Reconnect`, `Disconnect <account>` and `Add another account` — one reconnect/disconnect pair per account, labelled with the connection id, with no right-hand status column. Reconnect runs the existing re-verify path and never disconnects; Disconnect keeps the store-locked removal and its durable `◆ Disconnected` entry (ENG-6108).
- The /mcp catalog picker shows the "Connect" trailing status in the plain text colour instead of the accent purple, and the "No matching services" empty state now has one blank row above the shortcuts line and starts in the same column as the row labels.
- Fixed alias ("Add another account") MCP connections always registering an OAuth provider: per-account connection ids now follow the same catalog classification as their parent service, so a second account of a paste-a-key token service (or a requires-setup or otherwise non-OAuth service) is never offered a browser login whose stored grant dispatch would reject. The account keeps its parent's token-based treatment instead — a pasted `mcp_static_token` stored under the account's own `mcp:<connectionId>` key makes it dispatchable and verifiable exactly like the first account — and an account of a public no-auth service stays credential-free rather than being reclassified as OAuth (ENG-6108).
- The MCP service surface (/plugins picker, mcp host handlers, system-prompt inventory) now advertises only one-click DCR or user token/key connectors (2026-09-15 final catalog cut): the user-own-app OAuth path (GitLab, Miro, Supabase, Vercel, monday.com, ZoomInfo, …), the 32 local stdio adapters and the url-only tenant templates were removed from the shipped catalog, so the picker no longer surfaces providers Prime cannot connect with one-click auth or a user token/api key (ENG-6108).
- Removed the duplicate sentence under an MCP connect entry: the `◆ Connected <service> · <n> tools verified` header now stands alone, and the body keeps only what the header omits (added account, verification issue and next step, deferred activation).
- Added the same durable feedback for MCP disconnects: a successful `/plugins` disconnect, `/mcp logout <name>`, or `/logout` of an integration now leaves a muted `◆ Disconnected <service>` entry in the chat, with the removal scope and account on expand. A failed or partial removal keeps its honest warning and records nothing.
- Added a bundled `mcp` skill that teaches catalog search, connection checks, schema inspection, generic tool calls, and error handling for any MCP service.
- Added discovery APIs to the pre-imported `mcp` module: `list_plugins`, `search_plugins`, `list_connections`, `search_tools`, and `describe_tool`, with bounded pages, complete-or-fail tool discovery, isolated schema copies, and no credentials or raw provider errors in inventory results.
- Removed the bespoke Linear and Notion Python integration packages; those services now use the generic `mcp` module and connection records like every other service.
- Hardened MCP endpoint verification so an unresponsive server can never hang it: fetches, response bodies, and session-termination cleanup are now bounded by an abort signal with a cleanup grace deadline, and connection-record writes create the store file exclusively so a first writer cannot wipe another process's records, requeueing failed writes until they commit (ENG-6108).
- Fixed MCP verification and background probes so they can no longer overwrite an in-flight login's account claim; every verification write is compared against the record and credential snapshot it was computed from.
- Added an honest "Login in progress" state for accounts with an active login attempt, replacing the misleading missing-credential Reconnect across the service picker, connection inventory, and host actions; a second Connect or Verify waits while Remove stays available.
- Made reserved built-in names conflict-aware: an equivalent user declaration keeps working, while a disabled or conflicting same-name entry now shows an explicit conflict or disabled state instead of a Connected card that cannot dispatch.
- Restricted installed-account repair to its exact saved connection id at its durable approved endpoint, so changed catalog URLs are never silently followed and a pending placeholder alone is not treated as approval.
- Changed unreviewed imported OAuth entries to offer an explicit Connect attempt (with an unverified notice) instead of a blanket metadata-review block, while keeping real API-key, setup-required, and registered-client restrictions.
- Ordered the service catalog so connected accounts and ready-to-connect services appear first, with every service still searchable and visible.
- Added optional per-server OAuth client identity settings (`oauthClientId`, `oauthClientSecretEnvVar`, `oauthClientMetadataUrl`, `oauthScopes`), wired through one shared provider factory into both login and refresh registrations; a configured secret environment variable that is missing or empty fails closed before any network request.
- Changed the kernel runtime readiness check to require the MCP discovery methods (list_plugins, search_plugins, list_connections, search_tools, describe_tool), so a stale cached kernel venv is rebuilt instead of silently accepted (ENG-6108).
- MCP account logins and the /login and /logout service selectors now mount inline under the chat through the same auth-panel surface as provider logins (#2331) instead of centered overlay popups: the guarded staged OAuth dialog, the mcp-connections tab, and the /mcp login route replace the prompt area with stacked closers, focus restore, and terminal-rows-aware list sizing (ENG-6108).
- Paste-a-key MCP services are now connectable from the TUI: selecting a requires-setup token service (GitHub, PagerDuty, the Zoom endpoints, and the other catalog token services) opens an inline masked paste panel on the same inline surface as the OAuth login panel, prompts exactly ONCE for the service's single credential (labelled from the field, e.g. "GitHub personal access token"; alternative field names for the same credential share one prompt), and stores the result in the agent credential store (auth.json under the same `mcp:<connectionId>` key OAuth uses) with an explicit `mcp_static_token` credential shape — never settings.json, never a status line, log, or transcript entry (ENG-6108).
- The picker row for a pasteable service now reads as an action ("Enter paste token") instead of a dead-end hint, and an account picker for a stored token service keeps a "Paste a new token" row so a rejected or rotated token gets a new paste rather than a re-verify of the same value (ENG-6108).
- Catalog token services accept the stored pasted token as a credential source alongside the settings env var: eligibility, `mcp.config` dispatch (a `credentialSource: "static-token"` marker; the kernel attaches `Authorization: Bearer` from the endpoint-bound stored credential only), and verification all consume one shared usability rule (typed, endpoint-bound, non-empty bearer). Every fail-closed rule is kept — setup field ids are never read as env vars, credentials bind to the exact connection id and endpoint, reserved/shadowed names still fail, and an unset env var with no stored credential still reports setup_required. A service whose upstream collects more than one distinct credential (the catalog cuts those at import; a local source could still declare one) is not pasteable and stays honest setup_required instead of collecting values the single-bearer runtime would never send (ENG-6108).
- Token-service verification uses the stored pasted token for the real MCP handshake: success records the same durable "Connected <label> · N tools verified" entry as OAuth, a rejected or failed verification reports unverified ("Token saved for <label>, but connection verification did not complete: …") and never claims Connected, and a token rotated or removed mid-probe discards the result instead of marking the new token verified (ENG-6108).
- Reworked the generic MCP OAuth engine: SDK-standard client-auth-method negotiation (client_secret_basic/post/none), full RFC 7591 registration responses with persisted DCR client identity/secret and expiry, client-initiated metadata (SEP-991, configured client-metadata URL as client id when advertised), SEP-835 scope precedence (configured > protected-resource > omit, never a server-wide join), RFC 9728 origin-level resource audiences for pathful endpoints (Notion/Slack shape) with audience-pinned refresh binding, bounded and cancellable discovery/registration/token requests, and sanitized typed OAuth errors (ENG-6108, PR2256).
- Hardened MCP account recovery so no edge can silently strand a credential: logging out an account now removes a credential-only integration even when no connection record exists, a failed commit or its failed rollback now reports an explicit recovery-required state instead of claiming nothing changed, an ordinary login that wrote the account key mid-flight is never clobbered or deleted by a concurrent staged login, and one-shot store operations settle cleanly when the file lock itself cannot be acquired (ENG-6108).
- Staged MCP logins now move their credential to the account key with a disk-authoritative compare-and-set under the auth backend's own file lock (set-if-absent move, exact-own restore, remove-only-if-matching): a bystander credential written by another process can no longer be overwritten or deleted by a get/set race across instances, and disconnects whose record save fails after the logout report the honest partial state (logged out, change not saved, retry to finish) instead of claiming the account is still connected (ENG-6108).
- The generic /logout route now delegates an MCP account logout to one shared store-locked operation (verified credential deletion plus pending-attempt cancellation under the store->auth ordering, before the route touches auth): a concurrent finalize can never re-create the credential after the logout, a failed verified auth removal fails the whole operation and cancels nothing, completed account records are preserved (honest unbound/Reconnect state), and staged keys map back only through their recorded attempt nonce — never a blind split (ENG-6108).
- A staged-key logout (a login attempt's pending credential selected in /logout) now cancels the attempt — invalidating its reservation nonce so the in-flight login can neither finalize nor delete the record — while preserving the account shell record and never touching another client's ordinary-login credential on the real key; the route reports it state-neutrally ("This login attempt is no longer current; manage the account from /plugins") instead of claiming Logged out or Connected (ENG-6108).
- Every user-facing MCP OAuth login (initial /plugins connect, error-state reconnect, add account, /mcp login, the generic /login service options, and the config menu) now routes through ONE guarded host operation: the account is claimed under the connection store's file lock first (a nonce claim on existing records, a pending reservation for fresh ids — even credential-only legacy accounts, whose current on-disk grant identity is captured), the OAuth credential always stages under a per-attempt key, and a guarded finalize commits it with a full-identity compare-and-swap (set-if-absent for fresh accounts, replace-only-if-matching for intentional replacements) that consumes the attempt nonce and marks the record pending-verification; a cancelled or failed login releases the claim without touching the existing account, a failed record write restores the PREVIOUS credential under the same lock, and a concurrent logout cancels the attempt so a late OAuth callback can never reactivate or clobber the account (ENG-6108).
- Fixed explicit MCP logins disconnecting connected accounts, false login-success results, and unguarded OAuth fallback paths. Cancelled logins keep account settings available for reconnect or removal.
- Catalog MCP entries without OAuth now fail closed: only explicitly public no-auth, setup-ready rows are eligible for credential-free dispatch, and an expired grant without a refresh token, a wrong-type, or an empty-access credential is no longer treated as authenticated; a configured bearer env var is the only credential source when set (ENG-6108).
- The MCP service catalog cap now always keeps installed connections — including entries whose descriptor is still in a source — and reports explicitly when installed connections alone exceed the cap (ENG-6108).
- Added `/plugins` and bare `/mcp` as a searchable external-service picker showing honest connection states (Connect, Connected with verified tool counts, Reconnect, Needs verification, Requires setup, Disabled), with connect via browser OAuth, automatic post-login verification, and disconnect (ENG-6108).
- Added kernel host requests `mcp.list_plugins`, `mcp.search_plugins`, and `mcp.list_connections` exposing the supported-service catalog and the user's actual connections, with strict status filtering, bounded limits, and honest `nextCursor` pagination (ENG-6108).
- Added local MCP connection records (`~/.prime/agent/mcp-connections.json`) separating `connectionId` from catalog `serviceId` and binding verification to the endpoint; a stored token alone now reports as pending, never Connected (ENG-6108).
- Connected catalog services (Linear, Notion) are now served through the generic Python `mcp` route (system-prompt inventory + `mcp.config`), so per-service wrappers are no longer required for dispatch (ENG-6108).
- Changed MCP connection verification to run through the official @modelcontextprotocol/sdk client with explicit session termination, fixed safe failure categories (no endpoint URLs or server text persisted), and queued activation at the next turn/compaction boundary so a login during streaming never asks for a manual /reload (ENG-6108).
- Changed connection records to use file-locked read-modify-write writes with unique temp files, and bound every verification result to the grant it verified so a stale probe can never mark a rotated or disconnected account Connected (ENG-6108).
- Bound every stored MCP credential to its endpoint for catalog services and user servers alike: unbound or cross-endpoint grants are refused before any token fetch or probe, surface as Reconnect with a fixed category, and are excluded from dispatch; the OAuth registry reset hook now re-runs a full atomic provider reconciliation so catalog providers survive refresh and removed user overrides restore in one pass (ENG-6108).
- Verification guards now re-read fresh auth.json state at persist time, so a probe finishing after another client logs out or rotates the grant can never persist a stale Connected record (ENG-6108).
- mcp.connect reports connected only after a verified handshake (with tool count) and maps handshake failures honestly; stdio servers managed through settings can be disabled from /plugins instead of showing a fake disconnect (ENG-6108).
- Wired the /plugins picker and the mcp host handlers to one shared catalog resolver: the merged built-in SERVICE_CATALOG plus settings-declared local sources (mcpCatalogSources, ~-expanded, missing-file and duplicate-id diagnostics, total cap), with unreviewed imported entries surfacing as candidates rather than one-click Connect and user-placed local files connectable through the login dialog (ENG-6108).
- Added per-account connections: adding an account allocates a distinct connection id (its own credential key, record, and OAuth provider), the account picker reconnects or disconnects the chosen account, and per-account ids stay dispatchable through the same integrations, inventory, and verification machinery (ENG-6108).
- Account ids are allocated through a durable, file-lock-atomic reservation written before the login starts: cross-process races produce exactly one winner, configured user/catalog ids are never taken, and a cancelled login releases only its own pending marker (ownership-validated), so a late callback cannot remove or resurrect another client's account (ENG-6108).
- Service cards aggregate every account of a service: all account ids are listed and searchable, the inventory emits one row per account with its own status, and a remaining account keeps its service visible and manageable after the default account disconnects; connections whose optional catalog source vanished keep a pinned definition at the recorded endpoint (ENG-6108).
- Pending accounts retry verification explicitly without a relogin, error accounts keep Reconnect, every account has an explicit Remove action, and a login whose verification result could not be saved reports pending instead of a false Connected; one unreadable local catalog source no longer blocks startup — built-ins and other sources survive with a visible diagnostic (ENG-6108).
- Account logins stage their OAuth credential under a per-attempt key and commit it to the real account only through a lock-guarded finalize that validates the attempt nonce: cancelled, replaced, or failed-write reservations never receive a late credential, and reservation callbacks resolve only after the durable record write commits (ENG-6108).
- Every per-account status now flows through one computed helper (credential binding, expiry, and record combined): the plugin aggregate, the connection inventory, and the account picker agree, so stale Connected records surface as Reconnect; catalog metadata aliases are part of the search surface again (ENG-6108).
- Account-removal transactions now run under one store lock with finalize: disconnects delete the credential and the record atomically (removeAccount), a failed finalize write compensates its credential move under the same lock, and every one-shot store callback settles exactly once — batched reserves in a failing write all resolve false with no hang, no ghost, and a working retry (ENG-6108).
- Changed the MCP catalog and account pickers to match the compact inline model and provider pickers, with searchable single-line rows, selected connection details, explicit action hints, and preserved editor drafts.
- Clarified local-server disable and settings-only HTTP actions, preserved explicit verification and saved-data cleanup, and hid unsupported OAuth account actions for settings-managed connections.
- The MCP service surface (/plugins picker, mcp host handlers, system-prompt inventory) now advertises only zero-app self-serve connectors (2026-09-14 product decision): providers that require a provider-registered OAuth client (Figma, Slack, Gmail, Google Calendar/Drive, MongoDB Atlas) or whose self-serve path stayed unverified (Shopify, HubSpot, LogRocket, and others) were removed from the shipped catalog, so the picker no longer surfaces providers Prime cannot connect without a vendor-registered OAuth app (ENG-6108).
- Collapsed a service's /mcp accounts menu to exactly one Reconnect, one Disconnect, and one Add-another-account row: with several accounts, Enter on Reconnect or Disconnect opens a second inline picker that lists the accounts, and picking one runs the action on that connection id only (Esc or left there returns to the accounts menu without acting). Left arrow from a service's accounts page now navigates back to the /mcp catalog, remounted fresh; Esc still closes the whole chain and left in the catalog itself stays inert.
- Changed MCP connect outcomes ("Connected Linear (12 tools verified)" and its saved-but-unverified variants) from transient status lines into persistent chat entries styled like harness refinement notices: a purple `◆ Connected <service> · <n> tools verified` header over the existing wording, account and activation details on expand, and the same durable record when a mid-turn connect activates at the next safe boundary.
- Fixed paste-a-key connection outcomes rendering as a malformed-message error, named the service instead of the picked row, told rejected tokens how to recover, and tightened the accounts menu spacing and selection bar.
- Fixed duplicated rows and scroll counters in the MCP service picker: multi-line catalog descriptions are flattened so a rendered line is always exactly one terminal line.
- Fixed the /mcp picker chrome from live testing: the scroll counter aligns with the row indent, one blank line separates the list from the description line in catalog and accounts mode, and every inline picker opens with exactly one separator rule between the chat view and the picker (a titled panel draws the rule above its title; a headerless panel keeps the bordered search's top border as that rule, never both).
- Changed Enter on an account row in the accounts picker to re-verify the account instead of disconnecting it; only the explicit Remove row removes, and the accounts search now matches only the fields that distinguish rows (account label and connection id) instead of the description text every row shares.
- Reworked the picker search ranking: exact/prefix/word-start/substring matches on label, service id, and aliases rank far above description and setup-hint text, scattered subsequence hits no longer qualify, and a query that matches nothing shows the "No matching services" empty state — searching "vercel" against a catalog without Vercel now returns zero rows instead of eight unrelated connectors.
- Fixed the /mcp and /plugins service-catalog picker: the selected connector now gets exactly one fixed description line with the shortcuts directly underneath (no blank separator, no viewport-driven description resize), the visible row window rebuilds from current state on every render so frames can never disagree about which rows are visible or selected, and the scroll counter stays honest — it counts every rendered row, which is the shipped catalog plus installed connections pinned from records (75 + 2 = 77 for the ENG-6108 cut).
- Kept the /mcp picker open after every connect, disconnect, reconnect, paste, or add-account action instead of dropping to the prompt: the chain re-enters the right surface (that service's accounts menu while it still owns an account, otherwise the catalog), rebuilt from the live catalog and connection store so a removed account is gone and a fresh one shows. Esc still closes the whole picker, and an action that cannot proceed reports its status and never re-opens.
- Fixed Escape and Ctrl+C while steering messages are queued: the active run aborts and all queued user steering messages now start together in one new agent turn, preserving order and consuming the queue; an empty queue stays abort-only and the steering mode setting is unchanged.
- Private worker framing now decodes large frames in linear time across socket chunks: delivered chunks are kept as-is and a completed frame's bytes are joined exactly once, and consumed chunks are skipped via a head cursor with amortized compaction instead of being shifted off the queue one per chunk, so a multi-MB frame arriving in small writes can no longer pin the event loop.
- Fixed no-skill kernel bootstrap calls (postinstall, runtime-bootstrap) wiping the recorded Python skill map from the .bootstrap-version marker, which forced the next real session to re-sync every skill: a no-skill call now leaves the recorded skill set untouched and only skill-syncing callers rewrite the marker.
- Classified Windows worker named pipes as worker sockets in `prime-agent ps`, so worker pipes are no longer listed as daemons.
- Made the collapsed summary/header rows clickable in fullscreen chats: tools and IPython cells, agent messages, refinement and compaction/branch summaries, skill and injected-prompt cards, bash and shell blocks (including inside side-question popups), collapsible errors, startup resource sections, and custom messages toggle only the clicked item; Ctrl+O still resets all conversation detail globally.
- Harness digest ranking and harness search now weigh matched query terms by document frequency (tf-idf style), so rare distinctive terms rank above entries dense in ubiquitous words.
- Sped up first-run installs by skipping pip/setuptools/wheel seeding when creating the kernel Python venv; every kernel package is installed with `uv pip`, so the seeded tools were never used.
- Reduced Python kernel startup time by deferring the event-loop import stack (asyncio plus the shell tool's heavy stdlib imports) until after the ready event, with no protocol or behavior changes.
- Fixed harness digest re-delivery busting the provider prompt cache: cold boundaries (resume, context rebuild, post-compaction head) now compare a harness state fingerprint instead of the rendered digest text, so unchanged harness state no longer re-delivers a digest that turn-drifted relevance terms made look stale; the compaction summary carries the fingerprint for the same skip rule, and ranked digests break score ties on stable identifier order instead of `updated_at` recency so an unrelated entry update can no longer reshuffle the visible window.
- Fixed: compaction, branch, and refine summaries now label each serialized tool result with its tool name, so parallel tool calls can be paired with their results.
- Fixed: failed tool results are marked as errors in the label, keeping failure attribution visible in summaries.
- Fixed: serialized tool calls now carry a sequential `#N` prefix and results repeat the matching index, so repeated calls of the same tool pair unambiguously.
- Fixed the kernel stderr log (`kernel-stderr.log` in the session artifact directory) being created world-readable: the log is now owner-only (0600), and its directory is created owner-only (0700) when the kernel manager creates it, matching the kernel state snapshot and the other private session artifacts, because kernel stderr can carry exception payloads.
- Corrected the documented defaults in `docs/settings.md` and `docs/themes.md`: unset thinking starts at `medium` (not `xhigh`), the default theme is `prime`/`light` (not `dark`), `transport` defaults to `auto` (not `sse`, and `websocket-cached` is a valid value), and the removed `collapseChangelog` setting is no longer documented.
- Chats now start at the middle conversation-detail level (edit diffs expanded, thinking visible, tool output still summarized) instead of the most-collapsed overview; Ctrl+O keeps cycling overview -> details -> all unchanged.
- Added a pre-push guard hook that refuses mirror-like pushes and remote branch deletions to real GitHub remotes, with an opt-out via PRIME_AGENT_ALLOW_MIRROR_PUSH=1.
- Fixed opening an agent from Agents View during a daemon auto-update failing with "Daemon is preparing an update restart": the open now waits through the update restart (bounded) and reconnects once the daemon returns, with a notice that it waited instead of a hard failure.
- Fixed `heartbeats_list` timing out on busy daemons: the supervisor now answers from a shared in-memory scheduled-jobs snapshot (one in-flight disk scan serves every concurrent catalog request, heartbeat mutations drop the snapshot, aged snapshots refresh in the background), and sibling name scans no longer hold the serialized ledger queue that scheduled-catalog topology reads wait on.
- Fixed an unhandled error on the kernel child stderr pipe crashing the daemon worker: the stream now records a kernel diagnostic like stdin and stdout instead of reaching the daemon uncaughtException handler and exiting with every hosted session.
- Fixed short-lived sessions re-paying the whole Python kernel skill sync or wiping and rebuilding the venv after being killed mid-sync: the bootstrap version marker is now written atomically and persisted incrementally (base first, then after every installed skill), so the next session resumes only the remaining skills instead of starting over.
- Fixed spawn name reservations releasing before admission was durable, which let two parallel same-name spawns both admit and write duplicate ledger edges that made child selectors ambiguous.
- Added model and reasoning effort pickers for ACP clients such as Zed, with model-specific effort options.
- Reduced daemon disk churn: the scheduled-jobs catalog now re-parses only when its file changes, instead of on every heartbeat and agents-view poll and two to three times per mutation.
- Fixed worker CPU growing with session size: roster heartbeat flushes no longer re-walk every message for the latest-activity timestamp, no longer re-compose and re-serialize unchanged session summaries each cycle, and the heartbeats list no longer builds a full session summary per registered job per poll. Unchanged sessions reuse their last composed roster entry; any live-state change (new message, streaming, bash, compaction, verdict, or registration flag) still recomposes and publishes the same wire delta as before.
- Timer-driven goal and autonomous continuations now pause while background `bash()` handles are still running instead of re-prompting the waiting agent: the last handle settling is the wake-up (its completion notice is delivered first, then the held continuation resumes behind it without spending continuation budget while it waits), and the kernel now notifies the host when its live background handles settle or the kernel tears down.
- Added the `/speed [on|off]` session command: toggles a compact footer readout of model output tok/sec (latest response plus session average), computed from existing stream events with no provider protocol changes.
- Harness store writes now validate entry shape before persisting: `rlm.harness` create/update/upsert calls reject non-string or empty `title`/`content`, empty or non-string ids, malformed paths, non-dict `reference`/`arguments`/`metadata`, and skill entries without a valid Python reference, with a clear error naming the entry and the violated entry field; refinement events reject non-string triggers and invalid `changes`/ids. `/refine` and rollback edits reject the same shapes through `validateEdit`.
- The harness digest and refine overview now skip malformed persisted entries and refinement events (non-object events plus events with non-string ids, triggers, change elements, or outcomes, labeled by bounded type instead of value) with a `harness: skipped malformed entry <id> (...)` diagnostic line instead of crashing session creation, so a single corrupt store entry can no longer brick every session and child spawn.
- Added an `imageModel` setting that routes image-attaching turns to an image-capable model when the session or subagent model is text-only.
- Image turns on a text-only session model now fail with an actionable error naming `imageModel` instead of silently dropping the images when the setting is unset or unusable.
- Attached TUI windows now recover automatically when the daemon restarts: a shutdown close polls the same socket path for the reconnect window (60s by default) and then re-attaches the session and refreshes the transcript instead of dying; if the daemon stays gone, the saved-transcript message remains.
- Daemon update restarts now announce the update close reason on every attached window, so all windows (not just the one running /update) restore their sessions.
- A one-line banner reports restart recoveries, and warns to restart the window when the restarted daemon is newer than this window's binary.
- Fixed withdrawn background command completion notices silently dropping parked next-turn messages: cancelling a queued turn now re-parks its undelivered prefix records, so deferred context (kernel state restore notices, goal context, deferred RLM child terminal notices) is delivered on the next turn instead of being lost.
- Changed the session catalog scan to count tool-result (and extension-role) message entries from their serialized header instead of parsing their payloads, cutting the CPU a cold scan spends on transcripts whose tool output dwarfs everything else.
- Parked quota-blocked sessions now resume from a wake that survives aborts, restarts, and daemon-delivered wakes instead of clearing the park or stalling the resume, and a park no longer fails an active goal: the goal resumes with the task at the wake.
- Catalog metadata updates (renaming a saved session, archiving a stopped worker, marking a recovered session interrupted) no longer parse the whole transcript: each appends a single line after validating the session header, so routine actions on multi-MB sessions avoid the full-load stall and memory spike. A missing or header-invalid session file now fails the update with a clear error instead of being recreated or silently rewritten as a fresh session. The interruption notice stays advisory during worker recovery: a notice that cannot be written is logged, and recovery still reaps orphaned processes and resolves its journal.
- Changed the daemon to start its session catalog process on demand: the catalog is no longer spawned at supervisor boot, so an idle daemon keeps one fewer compiled runtime resident. The catalog spawns on the first session-file operation (agents view, `list --all`, session rename/delete/archive) and stays resident once started.
- Changed session context assembly to carry only the newest harness digest: older digest custom messages are skipped when the context is built, a fresh cold-boundary digest replaces the copies it supersedes instead of stacking, and a compaction head's digest snapshot yields to any digest appended after the compaction. Persisted transcripts are unchanged; the newest digest remains authoritative.
- Cached the active branch path in the session manager, so per-turn compaction checks and context-usage updates no longer rebuild the whole leaf-to-root path after every assistant message.
- `SessionManager.getBranch()` now returns the live shared branch array (public API): repeated reads return the same array object and straight-line appends extend it in place. Callers must treat it as read-only and take `.slice()` for a snapshot; `session_before_compact` already passes a snapshot.
- Fixed compaction summaries drifting behind the retained conversation: the summarizer now receives the newest kept-tail assistant text as a `<recent-state-anchor>` and the in-context `[compaction-summary]` prefix states that the retained messages below are authoritative.
- Fixed compaction file lists compounding through repeated summaries: `<read-files>`/`<modified-files>` blocks are stripped from the previous summary before the update prompt (entry details plus the fresh append remain the single source), and the combined file lists are capped at 6000 characters, dropping read-only entries first.
- New request timing diagnostics: `PI_REQUEST_TIMING=1` (or settings `requestTiming: true`) logs the phase timeline for each request made by the agent stream - prompt-built, request-sent (with body bytes), first-byte, first-token, stream-done - to `~/.prime/agent/logs/agent.jsonl` under `coding-agent.request-timing`, so a long `Waiting` state can be attributed to client-side build, upload, provider prefill, or a prompt-cache miss (summary usage shows cacheRead/cacheWrite). Zero overhead when disabled.
- Added a session-start `[python-skills-unavailable]` notice when a pre-imported Python skill fails to import into the kernel. The report names each failed skill import and its import error so the model learns before its first call instead of from the unavailable-skill placeholder, in both the TUI and headless sessions.
- Fixed kernel REPL protocol output that could buffer unbounded memory in the host: Python-level stdout/stderr writes now ship as 64 Ki-char frames, oversized result reprs are capped at 1 Mi chars with a marker, oversized display payloads fail the cell, and the host repairs a kernel that streams an oversized protocol line.

## [0.9.5] - 2026-09-15

- Removed the inactive-session collapse (Alt+I): inactive sessions always render in the agents view, and search remains the filter.
- Changed the default Prime Inference model from GLM 5.2 to GLM 5.3.
- Changed Agents View session statistics to use muted secondary text while preserving the available details ([ENG-6000](https://linear.app/primeintellect/issue/ENG-6000)).
- Changed Agents View session search to inline editable text without an input background or border ([ENG-6001](https://linear.app/primeintellect/issue/ENG-6001)).
- Changed refinement delivery to preserve the provider prefix cache: applying a refinement no longer rebuilds or swaps the system prompt. Applied edits now reach the model as a durable in-context `[auto-refinement]`/`[user-refinement]`/`[self-refinement]` notice at the apply boundary (zero-applied-edit refinements emit nothing, and the notice never starts a turn), and the harness digest moved from the system prompt to cold context boundaries: fresh sessions start with a digest message, post-compaction head messages render the digest before the summary on both compaction paths, and resumes append a fresh digest only when it no longer matches disk state.
- Fixed prompt templates altering literal dollar sequences and expanding placeholders inside user arguments.
- Fixed automatic compaction and recovery for LiteLLM maximum-context rejections.
- Fixed active goals stalling after manual compaction.
- Added the recorded model to inactive session rows in the agents view instead of showing '-'.
- Fixed Amazon Bedrock requests failing to load the provider in packaged CLI installations.
- Fixed Bedrock provider failures losing structured error severity and worker context in the shared CLI log.
- Fixed refinement and side questions disabling reasoning when the session uses it, while respecting the selected model's supported thinking levels.
- Removed fixed output caps from refinement with reasoning enabled, while respecting the model's output limit and reserving context space for the prompt.
- Fixed long refinements exceeding the context window or being rejected prematurely, keeping recent conversation text and space for the response.
- Changed recursive subagent spawning to the explicit `await rlm.spawn(...)` call; the `rlm` object is no longer callable and calling it raises an error naming `rlm.spawn`.
- Changed `rlm.spawn` to require an explicit `name` keyword argument for every spawned child.
- Unified all machine-injected user-channel messages under one bracket grammar: agent messages now open with `[agent-message from <relationship>:<name>]`, heartbeats with `[heartbeat: <schedule> run#<n>]` (previously the raw prompt with no marker), background shell completions with `[bash-done pid:<pid> exit:<code>]` (dropping the standing BashHandle hint), RLM child notices with `[child-exited: ...]`/`[child-failed ...]`, goal context with `[goal: <kind>]`, kernel state notices with `[python-state]`/`[python-state-restored]`, autonomous status and continuations with `[autonomous-status: on|off]`/`[autonomous-continuation(: gate-failed)]`, post-update restore notices with `[update-complete]`, and compaction/branch/harness-digest blocks with `[compaction-summary]`/`[branch-summary]`/`[harness-digest]`. Machine data (message ids, endpoints, pids, schedules) lives in message details, detection keys on customType instead of text regexes, and old-format persisted transcripts still parse.
- Removed `agent_message.list_agents()`; `agent_observe.list_agents()` is now the single family roster and lists inactive parents, siblings, and children with a `relationship` field.
- `/autonomous on` now accepts the same budget flags as the `--autonomous-*` CLI options (`--max-continuations`, `--max-turns`, `--max-tokens`, `--timeout-ms`, `--gate`, `--gate-retries`, `--gate-timeout-ms`), so interactive runs use a user-defined budget instead of always stopping after the default three continuations. The CLI spellings work as aliases and quoted gate commands are supported. Numeric values accept `,`/`_` digit separators, and the four budget limits accept `unlimited` to remove that cap. Named budget flags define the whole budget: unnamed limits become unlimited, so `/autonomous on --max-tokens 100,000` is bounded only by that token budget (plus gates); with no budget flags, the configured or default limits still apply. The status text now reports the time budget, configured gates, unlimited limits, and comma-grouped numbers.
- Added subcommand autocomplete to /traces, suggesting status, on, off, preview, upload, upload-current, upload-all, and login after the command.
- Changed the agents view model column to show the bare model name, stripping provider paths embedded in the model id.
- Changed the subagents bar to count running, idle, and inactive agents across the whole subagent subtree instead of only direct children.
- Background command completion notices are now withdrawn when the agent already read the result: reading a finished `bash()` handle from a live cell (awaiting it, or calling `poll()`, `output()`, or `tail()`) drops a notice that is still queued and stops one that was not sent yet. Reads that no cell receives, such as a detached watcher polling between turns, still leave the notice in place, so an unread completion wakes an idle session exactly as before, and a delivered notice is never retracted. The queue and transcript label for these messages is now "Background command finished" instead of "Shell message received".
- Changed `/btw` side questions to declare the session's tools without allowing their use: the request now matches the main conversation's cached prefix byte for byte (tools included), any tool call gets an error result instead of executing, and the side thread's first turn explains that it is a `/btw` side conversation with tools deactivated.
- Fixed `/btw` side questions discarding the main conversation's prompt cache by lowering the reasoning level: side questions now keep the session's thinking level, so providers whose cache keys include thinking parameters reuse the cached conversation.
- Changed refinement notices to show a spaced purple status line and softer semantic summary in overview and details, with full change counts and diffs in all output.
- Added expandable Title and Description diffs with the same red and green backgrounds as file edits, preserving other fields and failure details.
- Changed successful compaction notices to show a purple Context compacted header and softer summary preview, with the full summary and token/focus metadata in all output.
- Fixed refinement notices to stay purple across themes and avoid extra blank lines before following prose.
- Changed model, provider, and MCP pickers to compact inline lists with responsive search and keyboard navigation.
- Added selected-model catalog prices for input, cached input, and output per million tokens.
- Split the configuration menu into separate single-purpose pickers and dropped the tab bar and tab navigation; each command opens only its own picker.
- Changed model rows to right-align the provider label with a require sign in hint beside it, and to list signed-in providers first with Prime Inference pinned on top when signed in.
- Added per-model effort squares to the models picker; left/right adjusts the highlighted model's reasoning level and Enter applies the model and effort together.
- Fixed the models picker search to keep signed-in providers above unsigned matches, with Prime Inference pinned on top of the signed-in group.
- Softened the selected row highlight in menu pickers: the selection background blends toward the editor surface and the selected label renders bold instead of accent-colored.
- Refined the effort squares: clusters align across rows with arrow hints on the highlighted row, spaced squares in a stronger purple, and the selected level labeled beside them.
- Folded the USD per million tokens unit into the model detail header line and left clear whitespace at the end of the detail block.
- Rounded model picker token prices to at most three decimals, showing sub-$0.001 rates as <0.001 instead of a misleading $0.
- Centered the models picker effort cluster near the row midpoint with square glyphs; fills render light gray and reserve the saturated purple for the highlighted row.
- Removed the explanatory title and subtitle lines from the model, provider, and MCP pickers; the search row now leads each picker.
- Moved the model detail pricing unit onto the price row as "dollars per 1 million tokens" and left the provider/model line bare.
- Fixed the effort cluster so changing the level never shifts the row; the level label renders in a fixed-width cell sized to the longest supported level name.
- Refined the model picker effort marks to the larger medium-square glyphs, softened the effort purple, and shortened the pricing unit to "$ / 1M tokens".
- Dropped the provider/model-id line from the inline model detail block; the prices now follow the list row directly.
- Settled the effort marks on the filled ■ and empty □ squares, the largest square pair the terminal fonts cover.
- Tightened the effort square spacing; the squares now render edge to edge and the cluster stays centered.
- Fixed model selection retaining focus until the model and explicitly selected effort finish applying, preserving the default effort when it is untouched.
- Fixed arrow keys editing model searches and removed the unused configuration-tab binding.
- Moved muted conversation detail status directly above the prompt beside an ellipsized recap, with one blank line separating the row from the chat.
- Showed model IDs with colon-separated lowercase effort and context usage in the bottom-right tray.
- Kept fast mode beside model and effort, renamed session navigation to manage, and removed the repeated shortcut guide hint below the prompt.
- Hid the tray and subagents summary while pickers are open and showed depth only for subagent sessions.
- Kept slash command autocomplete completion-only: Tab or Enter completes the command, and pressing Enter again runs it.
- Removed unsolicited feature-discovery tips during agent runs and example prompts from the startup splash and editor.
- Removed the extra blank line above recap and detail status when no extension widget is shown.
- Kept the tray and subagent summary visible during slash-command autocomplete while hiding them for actual pickers.
- Renamed conversation detail states to Collapsed mode, Details mode, and Expanded mode.
- Prevented hidden subagent summaries from taking focus while a picker is open.
- Changed the agents view to hide abandoned empty saved sessions consistently during search, simplify model labels, and keep secondary metadata quiet.
- Changed the agents list to separate the splash from search, bold the shared column headings, mute populated status groups, and omit the global scope label.
- Changed idle and inactive rows to share one bold status circle distinguished by color, keeping the animated mark for running rows and sub-agent expansion available through its keybinding.
- Replaced chat and agents splash logos with a compact solid butterfly beside centered runtime metadata, with a text heading in narrow terminals.
- Changed the agents header to show three metadata lines: title and version, agent counts, and the working directory globally or numeric depth in nested views; retained the nested back breadcrumb and chat model line.
- Removed duplicate prompt suggestions from chat and agents headers.
- Fixed empty-state search feedback while replying to or renaming an agent.
- Changed assistant message body text to a new dimmed `mdBody` theme color, easing the wall of bright default-foreground text while headings, links, and code keep their styling.
- Changed prime-theme inline code to a darker neutral (#c8c8cd) so it stays distinct from the dimmed body text.
- Added a three-stage Ctrl+O cycle for overview, thinking and file diffs, and all output, replacing the separate Ctrl+J and Ctrl+T conversation shortcuts without changing saved traces.
- Changed thinking rows to stay hidden in overview and appear as dim text without a repeated heading in the other detail modes, including newly streamed thinking.
- Changed collapsed tool-call previews to render plain and dim instead of green or syntax-highlighted code, with dim line counts and durations, while expanded blocks keep full highlighting.
- Changed decorative bold text in the conversation surface to normal weight, keeping bold only where it marks state or a single critical item (selected rows, active tabs, the login verification code).
- Changed the conversation row hierarchy: event-row trailing detail (agent-message participants, tool command previews, line counts, durations) renders dim while leading labels keep their colors.
- Changed background shell completions to update identifiable command rows, with compact fallback notices and full notifications shown once at their original conversation position in all output.
- Replaced repeated conversation detail shortcut hints with a status label showing the current detail mode and configurable expand or collapse shortcut.
- Changed expanded file diffs to start at the normal chat inset while preserving code indentation and diff gutters.
- Changed sent and received agent messages to keep compact notices in overview and details, show full bodies only in all output, and use the shared detail cycle instead of a separate Ctrl+P toggle.
- Fixed spacing after background shell completions and matched unique literal assignment-only shell launches to their completion notices.
- Fixed multiline Python string colors across source lines and narrow wrapping, kept embedded string content out of collapsed code previews, and preserved statements after closing quotes.
- Changed expanded Python cells to nest input directly under the summary, align marked output beneath it, and separate full tool and message blocks.
- Fixed unwanted gaps between compact tool and agent-message rows when empty assistant messages or hidden thinking appear between them.
- Fixed missing separation between refinement notices and subsequent collapsed background shell completions.
- Fixed custom themes without `mdBody`, large expanded agent messages, and slow or unmatched shell completions caused by malformed launch arguments or blank lines.
- Removed obsolete thinking-visibility settings and unused transcript heading and hint state.
- Fixed indefinitely animated shell rows after ambiguous completion notifications while keeping unmatched results at their original timeline position.
- Added xAI Grok subscription authentication through the existing `/login` menu for all bundled tool models, with auth changes applied to the current session.
- Changed the agents view subagent expand/collapse control: the arrow now sits on the always-visible subagent summary line instead of hiding on the session row.
- Changed the agents view hint tray to describe the arrow keys in context — `→ open`, `→ expand`/`→ collapse` on a subagent summary line, and `← parent` only inside an agent scope — in place of the `?` actions hint.
- Added standalone macOS and Linux release archives that run without Node, npm, or Bun, including the Python runtime sources and application assets.
- Changed new installations to prefer verified compiled releases on supported machines, with Node installation available for other systems.
- Fixed reinstalling the same compiled release to restore its assets without modifying files used by existing processes.
- Fixed installation to preserve a public command replaced by another installer during download.
- Fixed terminal hangups leaving an installation lock behind.
- Fixed installing older releases that only provide npm packages through the default installer, including when an npm command already exists.
- Fixed interrupted compiled updates discarding the existing rollback target.
- Fixed reinstalling or upgrading through the installer after an incompatible compiled executable falls back to Node.
- Fixed interrupted fresh installations leaving a broken command.
- Fixed installer downloads to require HTTPS and reject redirects to insecure protocols.
- Changed macOS installation guidance to use the published installer until browser downloads are signed and notarized.
- Added migration from global npm installations to compiled releases during the next launch after an update, preserving settings and a Node fallback when migration cannot run.
- Fixed migration to preserve a newer compiled installation activated by a competing update.
- Fixed automatic migration delaying daemon startup, reusing incompatible compiled releases, and replacing a concurrent npm command.
- Fixed automatic migration blocking informational and automated launches, hiding installer progress, suppressing retries after cancellation, and silently deferring invalid compiled releases.
- Fixed migration from scoped global npm packages to compiled installations.
- Fixed background and informational launches starting migration downloads after the public command had already switched to a compiled installation.
- Fixed unsupported hosts attempting compiled migration downloads instead of quietly continuing with Node.js.
- Fixed Prime Agent production credentials and team selection to stay independent of Prime CLI configuration, with validated CLI credential reuse only during explicit login.
- Fixed explicit Prime CLI credential import for the default SDK services factory.
- Added verified updates and offline rollback for compiled Prime Agent installations, preserving sessions and restarting with the activated release.
- Fixed normal interruptions during rollback losing the release needed to undo that rollback.
- Fixed malformed compiled-release metadata causing unnecessary npm reinstalls and daemon restarts.
- Fixed interrupted compiled activation recovering the exact rollback target before another lifecycle change.
- Added conservative cleanup for abandoned installer staging and inactive managed releases while retaining live or uncertain releases.
- Fixed direct and planned rollback rejecting inconsistent release metadata, assets, paths, and executable versions before activation.
- Fixed failed activation recovery discarding the state needed to retry restoring the previous release.
- Fixed damaged compiled installations blocking repair and rollback to a healthy retained release.
- Fixed rollback planning after interrupted activation and provided repair guidance for older retained installers without recovery support.
- Fixed stalled executable checks holding the installer lock indefinitely during installation, rollback, or activation recovery.
- Fixed update guidance directing repairable compiled installations to a manual download instead of the update command.
- Fixed OpenCode compaction, refinement, and branch summaries failing because requests omitted the conversation identity.
- Sped up roster and family resolution by caching the RLM spawn ledger's replayed edges behind a file-stat guard: unchanged files reuse the cached edges instead of re-reading and re-parsing the whole ledger, while any writer's append (this process or another daemon) still forces a fresh replay.
- Fixed slow agents-view updates and searches in large session catalogs, while keeping streamed sessions and status ages current.
- Sped up opening long live sessions: events arriving during the snapshot load now replay incrementally instead of each one triggering a full transcript re-transfer.
- Capped resync and settings-rebuild transcript renders to the recent tail, matching the initial open.
- Stopped the chat from re-fetching the whole transcript when a live event lands between attach and the first render.
- Fixed event ordering and snapshot recovery when opening busy sessions, switching sessions, or reconnecting, while preserving live updates in headless modes.
- Fixed snapshot transfers continuing after a session closes.
- Limited memory retained by live updates while a slow snapshot loads.
- Fixed `heartbeats_list` failing with "Cannot list heartbeats while session worker is starting" by awaiting in-flight worker launches before enumerating heartbeats.
- Bounded the global `heartbeats_list` startup wait and stopped waiting on client-owned launches, so private session startups no longer stall the catalog past the caller's request timeout.
- Bounded the session-scoped `heartbeats_list` forward so a stuck worker fails inside the caller's request budget instead of hanging until the client transport timeout.
- Fixed re-opened sessions rendering an empty transcript until the next message when a transient control-plane failure interrupted the initial render.
- Fixed one unrenderable message aborting the whole transcript rebuild during a session resync.
- Fixed orphaned session workers retrying supervisor resurrection forever when no replacement can come up: they now exit gracefully after a bounded supervisor-lost window, closing active sessions first.
- Fixed a crash when returning to the agents view while a chat is still loading.
- Fixed shutdown being ignored after returning to the agents view during stalled chat startup.
- Removed heartbeat catalog loading from the wait when opening or leaving a chat.
- Fixed a kernel pipe write error (write EPIPE) crashing the whole session worker: pipe errors are now recorded as kernel diagnostics while the pending write rejects cleanly.
- Added `rlm.collect`, a typed non-steering fan-in for subagent results: it awaits direct children's runs with a bounded timeout and returns per-child result envelopes (status, settled, answer preview, error, duration, tool count) without growing the parent's message queue.
- Fixed agent-spawned shells hanging on interactive prompts: git commit/rebase without -m, credential asks, and pagers now fail fast or no-op because GIT_EDITOR, EDITOR, VISUAL, PAGER, and related variables default to non-interactive values.
- No-argument slash commands now show a `Usage: /<command>` error when given arguments instead of silently sending the text to the model; the input is preserved for editing.
- Formatting-only: applied biome's line-wrapping to `daemon-mode.ts` so the pre-commit hook no longer leaves working-tree drift after every commit.
- Fixed non-worker draft discards to be best-effort: teardown failures are logged instead of exiting the daemon, an in-flight attach keeps its draft alive, and get_rlm_children returns the merged roster (resident plus passivated children) that the attach snapshot advertises.
- Autonomous mode now holds timer-driven continuations while subagents run, mirroring the goal continuation gate: child replies and exit notices wake the parent, so idle status-check turns no longer consume continuation budget. The held continuation is delivered when descendants settle, and a configurable keep-alive valve (default one continuation per 25 minutes of continuous subagent activity, `/autonomous on --subagent-keep-alive-ms <n>`, `0` disables) lets the parent check for hung children.
- Escaping the onboarding splash or failing its login no longer permanently skips onboarding; the guide reruns on the next launch until a model is configured.
- Added a bounded wait-for-usage mode: quota/subscription failures (429s, usage limits) now wait for recovery with exponential-backoff pings (1s doubling to a 5m ceiling, jittered), resume exactly at provider-reported reset times, and stop at configurable attempt/duration bounds instead of killing the session mid-turn.
- Added transient-unavailability waits: after quick retries are exhausted on 5xx/overload/network (and 404 routing blips) failures, the session pings with the same bounded backoff instead of giving up.
- Added an opt-in `providerBackupModel` setting that routes failed turns to a user-defined backup model while the primary is quota-blocked or unavailable, with an explicit status-line indicator, session-logged primary->backup->primary transitions, and automatic return to the primary on recovery.
- Non-interactive CLI boots no longer hang on stdin: the boot-time piped-stdin read gives up after a short idle window (PI_STDIN_TIMEOUT_MS, default 250ms) instead of waiting forever on a pipe a daemon worker, agent harness, or CI runner holds open without ever writing or closing it, `--resume` of a session from another project fails fast without a TTY instead of blocking on a fork confirmation, `daemon attach` without a TTY reports an error instead of waiting for terminal input, and the deprecation-warning keypress wait is skipped without a TTY.
- Fixed model cycling being unreachable from the interactive UI: Alt+M / Shift+Alt+M now cycle scoped models (previously documented as Ctrl+P, which actually toggles message expansion), and all docs and the startup banner now name the real keys.
- Typo'd slash commands now fail fast with a suggested correction instead of being sent to the model as a prompt; genuine messages that merely start with a slash still pass through.
- Fixed goal token accounting regressing across compaction context rebuilds: the same goal's usage counter can no longer move backwards when a summary navigation reloads a stale persisted state, and a stale active snapshot can no longer revive a goal whose budget gate already fired.
- Fixed compaction summaries dropping the tail of tool results: truncated tool output now keeps the last 500 characters so errors and log tails survive compaction.
- Fixed compaction summaries never recording kernel-performed file edits: ipython tool results now contribute their structured edit diffs to the tracked file operations, so `<modified-files>` reflects the default toolset's edits.
- Added an `auxiliaryModel` setting (`"provider/id"`) that routes refinement LLM passes (auto-refine review and refinement planning) to a different model. These passes use their own prompt prefixes, so running them on the session model evicts the provider's prompt-cache entry for the session and forces a full context re-read on the next session request; the setting isolates those passes while falling back to the session model when unset or unusable.
- Prime Inference `anthropic/*` models now send anthropic-style `cache_control` markers (system prompt, last tool, last conversation message) so prompt caching engages on gateways that pass them through to the upstream Anthropic API, matching the Anthropic cache pricing the catalog already applies to those entries.
- Fixed an invalid `--thinking` level being only a warning while the launch continued with the default level; it is now a hard error listing the valid values, matching `--mode` strictness.
- Fixed the agents-view hint telling users to start "without --no-daemon" - a flag the CLI does not recognize; the hint now names the real condition (a daemon-hosted session; start normally without `--no-session`).
- Changed the continual harness digest from alphabetical truncation to relevance ranking: entries are selected by weighted term overlap with the active goal and recent messages (recency tiebreak), and a `harness.search(query, kind=None, limit=10)` kernel API returns ranked entries on demand.
- Sped up session appends and forking large sessions: the per-append assistant-message scan is now a cached flag, and session forks write through a single open descriptor instead of one append syscall per source entry.
- Added `autonomous` settings (`maxContinuations`, `maxTurns`, `maxTokens`, `timeoutMs`, each a positive number or `"unlimited"`) that persist the default budget for autonomous runs, so long-horizon runs keep a user-defined budget without re-passing `--autonomous-*` CLI or `/autonomous on` flags; explicit per-run flags still win.
- Added the `subagentDefaultModel` setting: `rlm.spawn` calls that do not pin a model resolve against this persisted default (shown in the spawn receipt's `model` field) instead of always inheriting the parent model; unset keeps inherit-parent, and an unavailable default fails the spawn instead of silently falling back.
- Fixed the bundled goal skill's canonical example, which still taught `token_budget=200000` against its own "set `token_budget` only when an explicit token budget is requested" guidance.
- Fixed `rlm.delete_subagent` rejecting the `RLMSpawnHandle` returned by `rlm.spawn`; it now accepts a spawn handle, a subagent row, or a child id/session name string, matching `rlm.collect`.
- Fixed vague subagent and top-level session model validation errors: unambiguous bare model ids (like "z-ai/glm-5.3") now resolve to their full selector ("prime-inference/z-ai/glm-5.3"), and unresolved references state the expected "provider/model-id" form with close matches instead of only "unavailable, unauthenticated, or expired".
- A bare reference that matches no authenticated catalog model still resolves to the parent model when it matches the parent's full selector, covering offline discovery or expired provider credentials; ambiguous references remain unresolved.
- Removed the dead `./hooks` subpath export from `@earendil-works/pi-coding-agent`; the `core/hooks` module was deleted in #454 and the advertised export already resolved to a nonexistent file.
- Fixed `rlm.create_session` sessions on private Prime Inference models failing every request with a provider 400: an unknown private route id (e.g. `internal/glm-5.3-fast`) no longer inherits the public provider default's zai thinking format, so created sessions stop sending the `enable_thinking` parameter the private endpoint rejects, and thinking `off` is no longer coerced to `low`. Public models keep their existing fallback behavior.
- Fixed errored sessions persisting fabricated completed verdicts: a session whose last turn ended in a model error (e.g. provider 400s before any work ran) no longer lets the status classifier invent a recap and a COMPLETED verdict from the task text. Such sessions now settle to an `error` task state whose summary carries the transcript's real error message, persisted with the same journal-dedupe discipline as model verdicts, and terminal turns with `stopReason === "error"` no longer persist `completed` without a final answer. A verdict fabricated by earlier builds and persisted before a daemon restart no longer survives: the restart-seeded status is exempt from the unchanged-content fast path, so the first sweep repairs it to the error verdict.
- Fixed invalid macOS signatures in standalone downloads and blocked releases whose final Mac archives fail signature or runtime checks.
- Added host-owned `ctx.setTimeout`/`ctx.setInterval` (plus matching clears) for extensions: throwing callbacks are reported through the extension error boundary instead of crashing the process, and pending timers are cancelled on unload. Raw global timers remain unsupported for scheduling extension work.
- Fixed a session worker wedging at 100% CPU: waiting for a session to go idle while queued input was blocked by a running bash command, compaction, or retry spun in microtasks without ever yielding to IO, freezing every session in the worker and starving daemon IPC.
- Fixed session model restore silently substituting another provider's same-named model right after a daemon restart: restore now waits (bounded, default 5s) for in-flight Prime Inference catalog and private-authorization refreshes to settle and retries the lookup once before falling back, so saved models like prime-inference/openai/gpt-6-astra are restored once auth and the catalog are ready instead of swapping to openai-codex/gpt-6-astra, which displays identically in the UI.
- Fixed goal continuation prompts delivering a stale accounting snapshot taken when the continuation was queued; usage numbers now refresh at delivery time so long-queued continuations report the current budget state.
- Added a persistent supervisor connection for daemon workers: cross-worker requests (agent messages, roster reads, root-session creation, renames) now multiplex over one `SupervisorLink` instead of opening a fresh supervisor connection per call. Requests are never retried in-flight because daemon commands are not idempotent.
- Added a dirty-tree guard to the bash tool: destructive git discard commands (`git checkout -- .`, `git checkout .`, `git clean -f...`, `git reset --hard`, `git restore .`) are refused while uncommitted changes exist, listing the dirty paths and the explicit bypasses (`allowDestructiveGit: true` or `PI_BASH_ALLOW_DESTRUCTIVE_GIT=1`). The guard probes the repository the command targets (following `cd` chains and `git -C`), refuses relocations it cannot replay safely, and fails open when dirtiness cannot be determined.
- Fixed cold chat openings waiting behind saved-session catalog scans ([#2259](https://github.com/PrimeIntellect-ai/prime-agent/pull/2259)).
- Fixed background scheduled-job scans slowing down agents with large saved chats ([#2259](https://github.com/PrimeIntellect-ai/prime-agent/pull/2259)).
- Fixed large chats downloading their transcript again after refreshing the model catalog during startup.
- Fixed beta-only and stable-only releases failing macOS validation because their artifacts were downloaded to the wrong directory ([#2265](https://github.com/PrimeIntellect-ai/prime-agent/issues/2265)).
- Fixed repeated full transcript scans when refreshing large saved-session catalogs.
- Fixed repeated filesystem path checks when refreshing RLM session catalogs.
- Fixed saved-session deletion records when a path alias changes during deletion.
- Fixed RLM child renames and deletions being ignored after a cached session path becomes a symlink or changes targets.
- Fixed left and right arrows moving the search cursor after a search in the models picker: once up or down moves into the list, they adjust the highlighted model's effort until the query is edited again.
- Added the `⚠` icon prefix to `showError` messages in the interactive TUI, matching the existing `showWarning` treatment ([ENG-6159](https://linear.app/primeintellect/issue/ENG-6159)).
- Removed the mcp service catalog picker, connection store, and oauth login flows (revert of #2256; the work will be relanded separately).
- Fixed CLI value flags (--model, --provider, and 15 others) being silently swallowed when their value was missing, and invalid --mode values being ignored; both now fail with a clear error.
- Fullscreen chats show a pinned top bar with the chat name centered in plain text and the session's total spend beside it; the bar stays visible in every scroll position and refreshes the spend after each turn.
- Changed the prompt queue so messages you send are delivered before queued agent-to-agent messages, background notices, and scheduled prompts, while keeping your own messages in the order you sent them.
- Added a persistent update channel. `/nightly` (or `prime-agent update --nightly`) warns that nightly builds may be broken, asks for confirmation, then switches self-updates to the nightly (`beta.json`) release manifest and runs the normal update flow with its busy-session confirmation. `/nightly off` or `--stable` returns to stable. Startup version notices follow the chosen channel.
- Changed provider logins, including the in-flow team and account selectors, to render inline under the chat in the compact picker style instead of a centered full-pane modal.
- Changed finishing a provider login to stay on the providers tab instead of forcing the models picker open; the models tab refreshes in the background so it is ready when opened.
- Added a separator rule above the inline provider login panel so the login section stands out from the conversation above it.
- Tightened the inline provider login panel: the sign-in link and provider guidance lead the panel, the repeated browser-open copy and section labels are gone, and the paste field keeps a single key-hint line.
- Fixed inline menu panels dropping their subtitle, so multi-line provider prompts keep every instruction line.
- Renamed the Prime team selection heading to "Select a Prime Team:".
- Fixed the TUI heartbeat view freezing on busy sessions: catalog fetches now keep the last snapshot after a 10-second deadline and retry on the next heartbeats_changed event, instead of waiting behind an active turn indefinitely. A timed-out fetch still applies its late answer and re-arms a short retry so the open view always converges, and a failed fetch now shows an error in the view instead of silently showing a stale catalog.
- Changed the first-run onboarding to a compact block anchored top-left: the brand mark over its animated field, a short description of what Prime Agent does, and a single action to log in with Prime Intellect.
- Changed onboarding to run every step inside that block: the Prime Intellect login, team selection, and the new questions all mount under the mark instead of opening full-pane modals or dropping to the prompt dock.
- Added a provider step after login where several providers can be connected in one pass, with a search field, a scrolling list, and check marks on providers already signed in.
- Added a trace-sharing question at the end of onboarding, which writes the agent traces setting and notes it can be changed later with /traces.
- Changed first launch to run one sequence for everyone: credentials already on disk (a Prime CLI token, an API key in the environment) no longer skip onboarding or divert it to the model picker; they only make the sign-in step instant.
- Changed team selection to be skipped when the account has no team or exactly one, and to list accounts by name with their handle.
- Changed onboarding to stay quiet: provider progress chatter, the credentials-saved status line, and the telemetry notice no longer appear during first launch; the telemetry notice surfaces on the next launch instead.
- Added `rlm.progress.note`, a throttled child-to-parent progress channel: children report short in-flight notes that surface as `progressNote`, `lastActivityAt`, and `activityStaleMs` on child snapshots and in `rlm.list_subagents()` roster entries, so the parent kernel sees child state without polling or interrupting. `activityStaleMs` measures active (monotonic) time since the last tracked activity and stays unset while a child's activity is `executing`, so a long tool call reads as busy rather than stale and a host sleep does not mark every running child stale on wake.
- Extended the kernel runtime readiness check to require `rlm.progress_note`, so a `PRIME_AGENT_KERNEL_PYTHON` override older than the progress-note API fails fast with an actionable message instead of an `AttributeError` mid-run.

- Added musl and baseline compiled releases so Linux hosts stop falling back to the Node installation. Releases now publish `linux-arm64-musl`, `linux-x64-baseline`, `linux-x64-musl`, and `linux-x64-musl-baseline` alongside the existing four archives. The installer detects musl (Alpine) and x86-64 CPUs without AVX2 and downloads the matching archive. musl archives need `libstdc++` (`apk add --no-cache libstdc++` on Alpine); when it is missing, the installer now names that package and stops instead of falling back to the Node installation, and a failed first install no longer leaves an empty installation directory behind.
- Fixed global flags written before a command routing the command to the model as a chat message; `prime-agent --offline model list` now runs the command, `--` still sends the word as a message, and a global flag a command does not accept fails with a clear error.
- Fixed moved global flags leaking past a `--` separator into an `mcp add` child command or a scheduled message; they now stay ahead of any `--`.
- Fixed `prime-agent --offline help` and `--offline help status` printing help instead of chatting; global run flags no longer count as help arguments.
- Made the version check and npm bridge test suites hermetic. They now clear the update and daemon-worker environment variables they depend on, and the bridge sanitises the environment it hands to spawned children, so both suites pass from inside a running Prime Agent session instead of only in CI.
- Scoped background service discovery to the state root the command runs in, so a run with an isolated HOME or agent dir only lists and stops its own daemons and `shutdown --force` no longer reaches daemons that belong to another root.
- Scoped discovery now also reads the pre-move supervisor registry (so daemons from before the registry relocation stay reachable under the same agent dir) and skips records whose agent dir can no longer be resolved, so one stale record cannot abort the sweep.
- Fixed installs that failed on a slow first run of the compiled executable, such as Rosetta 2 translation on Apple Silicon; the startup probe now waits up to 60 seconds, accepts a `PRIME_AGENT_PROBE_TIMEOUT_SECONDS` override, and reports a timeout as a timeout instead of claiming the executable cannot run on this machine.
- Usage analytics now report `libc`, `libc_version`, `cpu_baseline`, `os_release`, and `os_product_version` so musl and non-AVX2 coverage is measurable before the standalone-Node install path is retired; every probe is memoized, the linked glibc runtime outranks a merely installed musl loader, and `os_release` is the raw kernel release string, which custom kernels can make identifying.
- Changed onboarding for existing users (working model with configured auth) to show only the trace-sharing question, skipping Prime login and the provider picker entirely.
- Changed onboarding for existing users who already have traces enabled to complete silently without showing any questions.
- Fixed image paste in standalone macOS and glibc releases by embedding the available platform clipboard addon.
- Fixed release manifest parsing rejecting all native binary entries when encountering an unknown future platform; unknown platforms are now skipped while known-platform entries remain strictly validated.
- Added versioned native binary metadata so the v1 manifest schema stays compatible while the v2 schema advertises every musl and baseline archive.

## [0.9.4] - 2026-09-08

- A Python kernel that dies after a successful startup is restarted on the next use instead of every call being handed the dead kernel forever, and skill-MCP tools advertise their real input schemas again under mcp>=2 (the SDK renamed the field to input_schema).
- Moved the semantic-edge ledger's append and replay IO onto the shared event-log substrate. One behavior unified across both ledgers: an unterminated final line is an uncommitted append — skipped on read and truncated before the next append, never newline-completed.
- Made every durable JSON/JSONL state write crash-safe through one shared atomic-write owner (temp file + rename, Windows rename retry): auth.json is no longer written in place (an interrupted write can no longer log you out everywhere), the auth migration writes its destination before destroying its sources, racing first-time settings writers no longer silently discard each other, and the kernel bootstrap lock can no longer be stolen mid-reclaim. Session files now repair crash damage (torn tails, zero-filled records) at open instead of silently losing the next message, and a session lease whose owner file is momentarily unreadable is no longer treated as stale and destroyed.
- Fixed unbounded session-journal growth from derived bookkeeping: child usage attribution now flushes one entry per child turn instead of one per model request, and idle status sweeps no longer persist fabricated fallback verdicts, duplicate statuses, or retry failed summary generations (including paid model calls) every 25 seconds on unchanged content.
- Fixed session-list refreshes re-reading entire session files on every change: metadata scans now resume from the last scanned byte offset, stop at the file size seen at scan start, and concurrent readers of the same session share one scan.
- Fixed daemon request latency on large agent trees: the passive-subagent topology is derived once and memoized, with every consumer (session list, snapshots, cron recovery, agent messaging, passivation) reading the cached walk until the spawn ledger, residency, or a child session file changes.
- Seven small correctness fixes: compaction keeps only the final turn when the budget is crossed inside trailing tool results (instead of silently keeping everything); a retry whose scheduled continue cannot run ends the retry instead of leaving the session stuck retrying; saved subagent sessions with a lost parent edge still display as subagents; tail truncation rescues an oversized final line even when output ends with a newline; a failed output-spill stream degrades to the in-memory tail instead of crashing the process; piped stdin and a CLI instruction are joined with a blank line instead of glued together; and frontmatter parses behind a UTF-8 BOM.
- Prevented session export and daemon-client startup from repairing or rewriting transcripts owned by another process.
- Enforced the retained session-scan usage cache limit for oversized transcripts.
- The WebP EXIF chunk scan reads chunk sizes as unsigned, so a crafted or corrupt image can no longer hang the process in an infinite scan loop.
- Fixed chunked session-snapshot transfers so the transfer id names the exact materialized snapshot cut, and a mismatched or restarted transfer now fails only that transfer (clients resync) instead of bouncing the whole worker channel.
- Fixed zombie processes being treated as live owners by the daemon supervisor ownership registry, session leases, supervisor launch locks, `daemon ps` process stops, and update-restart liveness checks; all process liveness probes now share the zombie-aware helper.
- Fixed daemon sessions bricking behind a terminal failed worker state: attach, create, and retry now re-run recovery for a failed worker whose process is verified alive, and a known-but-still-recovering session answers with a structured retryable error instead of "Unknown active session".
- The zai provider default model now points at glm-5.3; the previous default was removed from the catalog and silently fell back to a template model.
- Removed error-message matching from stale-auth decisions; only structured authentication failures mark credentials stale.
- Added recovery from stale authentication through validated explicit model selection, while preserving cached private-model access only for the selected Prime team.
- Changed auto-retry to honor provider Retry-After and usage-limit reset delays, capped by `retry.provider.maxRetryDelayMs`; longer requested waits fail immediately with an informative error instead of sleeping invisibly inside provider SDKs.
- Removed the `retry.provider.maxRetries` setting; provider SDKs no longer retry internally, so `retry.maxRetries` is the single retry knob.
- Changed structured `invalid_request`/`refusal` provider failures to fail immediately instead of being retried once.
- Added the shared retry policy to side questions, compaction and branch summarization, and refinement calls, which run outside the session auto-retry loop and would otherwise make exactly one attempt.
- Fixed the Python kernel bootstrap on native Windows: the venv python now resolves under `Scripts\python.exe` (uv layout). ([Discussion #1401](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1401), [Discussion #1969](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1969))
- Fixed `~/` and `~\` path expansion on Windows, including mixed-separator paths like `C:\Users\u/rest`. ([Discussion #1442](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1442), [Discussion #1469](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1469))
- Fixed daemon worker handshakes timing out on slow machines: per-attempt hello/auth waits now consume the remaining connect budget instead of restarting a fixed 1s clock on every retry. ([Discussion #1622](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1622), [Discussion #1678](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1678))
- Fixed console windows flashing on Windows: all background spawns now run with hidden windows. ([Discussion #1461](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1461))
- Fixed bash resolution picking WSL's System32 `bash.exe` over a per-user Git Bash on PATH. ([Discussion #1437](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1437))
- Fixed the built-in Herdr reporter never connecting on Windows by dialing the socket inside the named-pipe namespace. ([Discussion #1399](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1399))
- Fixed Windows worker startup deadlines, session lease contention, and UTF-8 Python execution.
- Fixed deleted subagents returning in saved display state and duplicate cleanup failure notices.
- Fixed the agents view blocking Enter with "Waiting for the selected session to load" while the remembered selection was still loading; opening the visible row now always works, and entering a subagents view no longer arms that wait at all.
- Changed the agents view to show the model label on every session row, not only on subagent rows.
- Added steering Shell messages when background kernel `bash()` process groups finish so agents can inspect results at the next safe turn boundary without interrupting running tools.
- Kept sessions resident while background shell process groups run and completion delivery is pending.
- Simplified the agents view with total cost and age, one column header, and collapsed inactive sessions while keeping the logo, startup metadata, and search.
- Kept a running-subagent count beneath collapsed agents while their subagents are working.
- Highlighted `@path` file references and `--flags` in the editor, queued message previews, and sent user messages, plus the bare `--` end-of-options separator in recognized slash commands.
- Added live refreshes for public and authorized private Prime Inference models while retaining bundled and cached fallbacks.
- Added `rlm.create_session(...)` so daemon-backed root agents can start separate top-level sessions.
- Preserved active same-provider credentials when creating a sibling session without storing them in daemon descriptors.
- Fixed daemon session workers crashing when a hosted extension touched `ctx.ui.theme` (theme was never initialized in the worker process); workers now initialize the settings theme headlessly at startup, without a theme file watcher.
- Fixed assistant Markdown file links to open relative to the session's working directory, including Windows drive paths ([#2108](https://github.com/PrimeIntellect-ai/prime-agent/issues/2108)).

## [0.9.3] - 2026-09-06

- Fixed ChatGPT OAuth model discovery hiding GPT-6 Astra by advertising Codex CLI 0.153.4 instead of 0.147.0.

## [0.9.2] - 2026-09-05

- Fixed daemon session creation after macOS timezone changes ([#879](https://github.com/PrimeIntellect-ai/prime-agent/issues/879))
- Fixed the stable installer failing under npm 12 when resolving verified release dependencies. ([Discussion #1988](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1988))
- Added native callable tools for MCP servers supplied by ACP clients. ([#2002](https://github.com/PrimeIntellect-ai/prime-agent/pull/2002))
- Reworked agent-trace upload scheduling as a disk-cursor outbox: upload intent and per-session uploaded-content cursors persist as one small entry file per session under `agent-traces-outbox/` in the agent dir, a startup catch-up uploads anything a previous process never finished (pruning cursors of deleted session files), scheduled and catch-up uploads never re-send unchanged sessions (the explicit `/traces upload` command still force-uploads), and rate-limited uploads reschedule (honoring an advertised Retry-After) instead of sleeping. Session disposal and process exit no longer wait on trace uploads at all, and upload timers never keep the process alive; the exit drain barrier is gone (the startup catch-up replaces it).
- Fixed finished agents lingering in the agents view Running section as "classifying" when their status summary text did not change.
- Extracted the RLM spawn ledger's crash-safety mechanics (single O_APPEND writes with optional fsync, bounded fail-closed replay, torn-final-line tolerance, repair-on-append) into a shared append-only event-log substrate; ledger behavior and public API are unchanged.
- Fixed sessions with armed heartbeats showing as Running forever in the agents view; between firings they now list as Idle with the heartbeat badge and a `heartbeat · next <time>` label.
- Added a dimmed heartbeat badge for sessions whose only heartbeats are paused.
- Added an armed-heartbeat warning to the agents-view delete confirmation for sessions and subagents.
- Changed sessions with armed heartbeats to passivate like any idle session; the daemon now wakes them when the next heartbeat is due, including after a daemon restart.
- Fixed heartbeats of passivated sessions disappearing from the heartbeat list and agents-view badges.
- Added an ACP semantic-edges-v1 producer: each agent session appends an append-only `semantic-edges.jsonl` ledger beside its session artifacts, every provider turn and compaction summary call carries one opaque request ID on `X-ACP-Model-Request-ID` and `Idempotency-Key` (minted before the call, committed or failed when its stream resolves, and stable across retry attempts of the same call body), spawned subagents record their parent session and spawning request while successful children record their return, and `deriveSemanticEdges` folds a session tree's ledgers into commit-gated `continuation`/`subagent_call`/`subagent_return`/`compaction` edges matching the verifiers semantic-edges-v1 schema. Derivation only — nothing publishes or reads the ledger yet.
- Registered the per-session semantic-edge ledger with the agent-traces outbox as its own kind-tagged entry: durable upload intent at persist, an append-only byte cursor that never re-counts unchanged ledgers, startup catch-up counting, and pruning when a ledger is deleted with its session. No delivery endpoint exists yet, so pending ledgers are counted but never sent.
- Fixed the agents view undercounting running subagents: the "N subagents running" indicator now counts busy descendants at any depth, stays visible on collapsed groups, and idle sessions with busy subagents sort above plain idle sessions.
- Changed the agents view Running section to mean the session's own work: sessions whose only activity is delegated to subagents now list as Idle with the running-subagents badge.
- Daemon- and runtime-hosted subagents record their spawn lineage again (the production runtime factory dropped it), and a compaction summary slice that resolves after a sibling already failed the compaction settles as failed instead of staying in-flight forever.
- Added token and cost details to agents view rows: input/output tokens plus the session's own cost and its recursive total including all subagents; the message-count detail is gone.
- Fixed stopping or deleting an agent whose tree holds finished intermediate subagents: the walk no longer re-visits subtrees exponentially (which could freeze the worker on deep trees), and one cancel press reliably reaches every running descendant.
- Kernel process stderr now lands in `kernel-stderr.log` in the session artifact directory (rotated at kernel start and capped by a 5 MiB per-spawn write budget), and the in-memory diagnostics tail is bounded instead of growing for the kernel's lifetime.
- Changed agents-view row usage to aligned `↑in ↓out · $agent · #sub · $total · age` columns with an explicit total-subagent count; empty sessions show only their age.
- Added a bold usage legend and session count to every agents-view section header, sharing one column layout with the rows.
- Changed empty sessions to sort last within their agents-view section, except the session the view was entered from.

## [0.9.1] - 2026-09-01

- Fixed a v0.9.0 regression: the agents view's Inactive section was empty on a fresh view until a search was typed. The saved-session catalog now loads (progressively) when the view opens; it was previously deferred to search because the roster's boot seed carried the saved corpus, which the seed scoping removed.

## [0.9.0] - 2026-09-01

- Fixed background (unattributed) kernel output missing from the expanded IPython cell view: it is now surfaced in the tool details and rendered under a "background output (unattributed)" label after stdout/stderr/result.
- Fixed a protocol interrupt during a REPL state restore leaving a mixed old/new namespace: names are now staged first and applied atomically with SIGINT parked across the apply, and an interrupt landing anywhere between a committed snapshot or restore and its request finishing is recovered instead of misreporting the completed operation as failed.
- Fixed the REPL snapshot writer leaving a new payload beside a truncated manifest on mid-write failures: payload and manifest now commit via unique same-directory temp files and atomic renames with guaranteed cleanup, and an interrupt during cleanup can no longer misreport a completed destructive snapshot as failed.
- Fixed the REPL runtime `list_names` request crashing the serve loop when the namespace held a non-string key; non-string keys are now skipped and every runtime request fails individually through the shared backstop instead of killing the loop.
- Addressed REPL host-swap review findings: reworded stale IPython-specific busy/restart messages for the default kernel and stopped `restart()` from resurrecting a concurrently killed REPL kernel.
- Fixed graceful REPL kernel `shutdown()` losing teardown ownership to its own child's exit handler, which made `restart()` misread the shutdown as superseded and never start the kernel again.
- Fixed REPL kernel `start()` waiting out the full 30s ready timeout when the kernel process fails to spawn; the spawn error now rejects startup immediately.
- Fixed a cell that rebound or ignored SIGINT (or a restored prior handler) permanently breaking protocol interrupts: the REPL runtime now re-asserts its SIGINT handler between cells.
- Fixed the Python REPL runtime surviving its owning process's death while a non-yielding cell runs: an owner-watchdog thread now hard-exits the runtime (killing live bash children first) when the owner process dies.
- Fixed an interrupt parked during a snapshot's prune window misreporting the completed destructive snapshot as failed; it is now consumed once the manifest is committed, and an interrupt landing just after a completed snapshot/restore request is consumed too instead of failing its done.
- Fixed a REPL runtime interrupt gap where an interrupt landing during a cell's trailing-expression repr or output drain was dropped; the request now stays interruptible until its done event is emitted, so a slow user __repr__ can be cancelled.
- Fixed two REPL runtime request-lifecycle bugs: a cell closing sys.stdout/sys.stderr no longer kills the serve loop (done still arrives and later cells run), and an untargeted interrupt parked for a request that fails to compile is consumed with that request instead of spuriously cancelling the next cell.
- Fixed the REPL runtime leaking a finished cell's id onto late background-thread output: the current cell is now cleared right after the post-cell drain, so `done` stays the last event with that id and between-cell output carries a null id.
- Fixed bash() cells failing under strict-POSIX shells (dash) when the status pipe landed on a multi-digit fd.
- Fixed rlm.run outside a live kernel hanging forever instead of failing fast, which stalled CI shard 3 until timeout.
- Fixed two bash() spawn races: status-channel fds no longer leak when pipe creation fails mid-setup, and a status-socket gate keeps the command from starting until its pid is journaled (a kernel kill in that window now stops the child instead of orphaning it past the reaper).
- Fixed a compile-phase crash (e.g. RecursionError from a pathologically deep attribute chain) killing the REPL runtime instead of failing the one cell: any per-request failure now becomes error+done and the serve loop keeps running; rebinding sys.stdout/sys.stderr to flush-less objects no longer kills it either.
- Fixed the REPL runtime hanging before done when a cell closes fd 1/2 and a later open() reclaims the number: drain sync tokens now go through a private dup of the capture pipe, with a pump-liveness backstop so a dead pump can no longer wedge the serve loop.
- Fixed the Windows orphan reaper killing only the journaled bash() shell pid; it now uses taskkill /T so descendants die with the tree, matching the in-kernel bash() kill paths, and resolves taskkill via an absolute System32 path (with NoDefaultCurrentDirectoryInExePath) so a planted CWD taskkill.exe cannot hijack cleanup.
- Fixed a snapshot request with identical `path` and `manifest_path` silently clobbering the just-written state payload; the runtime now rejects it as a failed request.
- Fixed a snapshot request with a negative `max_bytes`/`max_variable_bytes` and `prune_oversized` writing an empty payload and then deleting every user variable; size caps must now be non-negative integers.
- Fixed an interrupt landing mid-snapshot leaving prune deletions half-applied: once the snapshot manifest is committed, SIGINT is deferred until every oversized name is removed, so the namespace always matches the on-disk snapshot.
- Hardened bash(): cancelling `await bash(cmd)` now kills the command's process group (background handles are unaffected), Windows helper binaries resolve via absolute System32 paths, kill() retries taskkill for already-reaped Windows trees, and orphan-journal enrollment fails closed when configured.
- Fixed cross-cell output misattribution in the REPL runtime: stream events are attributed at write time via context, and raw fd or user-thread output is emitted with a null id instead of being credited to whichever cell is running.
- REPL kernel: output from user threads, other cells' leftovers, and raw fd writes is no longer merged into the running cell's stdout; it is surfaced separately as unattributed background output.
- Hardened bash() further: the host now injects an absolute default shell into the kernel (no PATH lookup; /bin/bash else /bin/sh on POSIX), macOS start-id lookup uses /bin/ps, and Windows worker-teardown orphan kills go through hardened taskkill /T.
- Hardened Windows bash execution: the kernel shell is resolved only from trusted absolute paths (never PATH), and bash children are contained by kill-on-close job objects so a crashed kernel cannot leak process trees (taskkill remains only as a fallback when job creation fails).
- Hardened Windows bash() containment: children are now created directly inside the kill-on-close job (PROC_THREAD_ATTRIBUTE_JOB_LIST at CreateProcessW time), so no window exists in which a kernel kill can leak a suspended, never-run process; handle inheritance is restricted to exactly the child's stdio handles (PROC_THREAD_ATTRIBUTE_HANDLE_LIST), so concurrent spawns cannot leak each other's handles; the journal start-id query still runs only while the job-contained child is suspended, and bash() still raises instead of falling back to jobless taskkill when containment fails.
- Fixed a Windows bash() PID-reuse hazard: the child process handle is now retained through job cleanup and every taskkill-by-pid fallback (watch reap, kill(), cancel escalation, shutdown cleanup) and closed exactly once only after the handle is marked reaped, so a recycled pid can never be killed by the fallback.
- Added an async-by-default `bash()` callable to the kernel runtime: it returns a live handle immediately (pid/tail/poll/kill/await), bounds in-memory output, and enrolls children in the orphan-process journal so kernel teardown reaps them.
- Fixed bash() orphan-journal writes marking a child inactive even when the kill signal was not delivered; the record now stays active on delivery failure so the host reaper still owns the process (on Windows a shell that already exited counts as delivered, so clean exits still retire their record).
- Changed the kernel to run on a minimal CPython REPL runtime speaking JSON lines over stdio.
- Changed the kernel to a minimal Python REPL: `%%bash` cells, `%cd`, `%env`, and `!` escapes were replaced by `bash('cmd')` and `os.chdir(...)`/`os.environ[...]` (magic-style cells fail with a plain Python `SyntaxError`); startup is faster and memory use is lower.
- Removed the Jupyter/ipykernel kernel client; existing kernel venvs are rebuilt once (slimmer, no ipykernel) on next start.
- Fixed supervised session renames failing after the supervisor approved an available name.
- Made session path detection consistent across direct and daemon commands.
- Removed internal test-only configuration cache reset hooks.
- Fixed new-chat hints to use the session message count.
- Kept available model lists in sync with the current catalog and configured providers.
- Removed unused host-request capability helpers and the `kernelManagerRef` option from `IpythonToolOptions`.
- Fixed `bash()` to capture all foreground command output before finalizing results by using an ordered per-command completion marker; output written after the marker (e.g. by `EXIT` traps or background jobs) is not in the awaited result but stays visible via `handle.output()`/`tail()`.
- Agent messages now use core session admission to choose immediate or queued delivery.
- Made cross-worker agent lists current without broadcasting duplicate peer rosters.
- Namespaced kernel host handler results so handler fields cannot overwrite host reply protocol metadata.
- Fixed graceful Python kernel disposal so timed-out final snapshots are cancelled before teardown.
- Fixed invalid kernel protocol frames hanging requests by rejecting the affected request and replacing the kernel from its latest state snapshot.
- Fixed kernel teardown so session cleanup and signal handling share one bounded graceful shutdown path.
- Fixed remote agent messages being delivered twice when the daemon request timed out or the response was lost: the message is now sent exactly once per call, and post-send failures surface as errors instead of triggering a resend.
- Simplified model resolution and feature hint shuffling internals.
- Fixed saved-session resume when its resident worker is still recovering after a daemon restart.
- Fixed queued-message editing so duplicate prompts always target the selected queue entry.
- Fixed reattached sessions omitting queued child agents or showing the wrong child activity.
- Fixed passive RLM child metadata recovery from legacy registries without a session directory.
- Stopped treating `NODE_ENV=test` as an implicit telemetry opt-out.
- Removed delayed cancellation callbacks from empty interactive selectors.
- Kept heartbeat lists current when session or subagent scope changes.
- Removed the delay before continuing sessions after compaction.
- Wait for RLM session activity changes without zero-delay polling.
- Fixed concurrent `execute_bash_and_wait` commands sharing one bash abort controller: each `executeBash` invocation now gets its own controller, so a finishing command no longer clears a still-running command's abort state and `abortBash` cancels every in-flight command.
- Removed the test-only daemon active-session lookup override.
- Made daemon shutdown wait for Bash completion without polling.
- Fixed a race where a concurrent open of a session already being opened by another client bypassed the session ownership check instead of failing with session-already-active.
- Accept contributions from sirouk as a vouched external contributor.
- Render Mermaid code blocks in assistant messages as inline Unicode diagrams, with a "Mermaid diagrams" setting (off/final/streaming, default streaming).
- Tell the model explicitly to run shell commands through `bash()` instead of `subprocess`/`os.system`.
- Fixed `prime-agent list` pinning an abandoned empty session at "working" forever; an empty session with nothing in flight now reports "idle".
- Evict an empty, unnamed session's worker as soon as its last client disconnects, instead of parking it for the idle sweep; the on-disk draft session is preserved.
- Fixed daemon session create when the worker process cannot be spawned (e.g. EMFILE from fd exhaustion): the create now fails with the real spawn error plus a resident-worker/ulimit hint, and the CLI prints a one-line error instead of crashing with a TypeError stack dump.
- Fixed the agents view hiding running subagents whose worker is starting or recovering; the worker state now shows as the row's status label.
- Made spawned subagent sessions visible from creation, before their first message lands.
- Renamed the subagent summary bar label from "agents" to "subagents" and unified the status formula behind both surfaces.
- Made the daemon supervisor own an event-driven agent roster: workers push roster deltas on session events and `list` is served from the supervisor's ledger with zero worker round-trips. Rows are as fresh as the owning worker's last delta; a silent worker's rows are annotated (recovering, last-heard-from) rather than dropped, and the surfaces that display those annotations ship in the follow-up PR.
- Tracked admitted subagent runs in the supervisor roster from the moment they are queued (they appear in `list` once their session exists), and kept passivated or evicted agents listed as inactive rows instead of disappearing (client-owned workers stay private: their rows are dropped when the worker goes away).
- Tracked worker liveness in the supervisor roster: a dead worker's rows are flagged "recovering" the moment its socket closes, and rows of silent workers carry a last-heard-from time. These fields are supervisor-internal here; the roster surfaces that display them ship in the follow-up PR.
- Replaced the agents view's 1-second polling with a subscription to the daemon's agent roster: the supervisor pushes coalesced roster updates, scope transitions reuse one shared connection and store without refetching, and rows render the ledger's statuses and lifecycle labels (queued, recovering, failed, last-heard-from staleness). Removed the poll path: the agents view now requires the daemon's agent_roster capability and fails fast against a daemon lacking it (unreachable in practice, since launch replaces daemons on any schema mismatch); the chat subagents bar degrades to snapshot-driven counts.
- Loaded the saved-session catalog only when a search query needs deep message text, once per view, instead of on every navigation.
- Fixed a reconnect deadlock where a daemon socket close during recovery or post-update restore parked the reconnect loop's own attach, snapshot, and list requests behind a hello that the stuck loop could never produce ([#1905](https://github.com/PrimeIntellect-ai/prime-agent/issues/1905)).
- Collapsed ipython cells that call the bash skill with a literal command now preview as `bash · <command>` instead of the python wrapper.
- Added a direct session transport: the TUI now talks to its session's worker over a supervisor-issued single-use ticket, falls back to supervisor routing on any direct-path failure, and keeps the session streaming while a lost supervisor socket reconnects in the background.
- Workers bind their identity to a fresh per-process instance id, enforced only when the authenticating supervisor presents one, so a downgraded supervisor can still adopt live workers.
- Fixed daemon startup and recovery to preserve slow live processes and fail closed after socket lock loss.
- Recovery never signals a live worker process it cannot verify as its own: a persistently failing live worker parks as failed with its process left running (reclaimed automatically by the next fresh create once its identity is verified or it exits). The one deliberate exception is replacing an authenticated pre-roster worker during adoption. A live worker that stays silent through ten probe rounds (~2.5 minutes) also parks as failed instead of probing forever.
- Reduced kernel memory spikes during namespace snapshots: the payload now pickles straight into the staged file instead of building serialized copies in memory (peak snapshot overhead ~3.9x payload -> ~1x; ENG-5819).
- Fixed empty draft sessions lingering as zombie rows after the last viewer quit: a direct-transport client's detach or socket drop now triggers the same last-detach eviction as supervisor-routed clients.
- Stopped re-emitting `rlm_child_update` events whose child snapshot did not change; identical per-token progress updates no longer reach attached clients.
- Fixed `/update` keeping the old TUI process alive until the relaunched TUI quit by replacing the process in place on POSIX platforms running Node 26.1 and newer; Windows and IBM i keep the previous child relaunch.
- Fixed sent agent messages under Python cells not showing the expand/collapse keybinding hint that received agent messages show.
- Scoped the roster's restart seed to registered workers' families: the saved-session corpus stays owned by the disk catalog, so a supervisor restart no longer publishes thousands of inactive rows (and one header read per row) to every roster subscriber. `prime list --all` output is unchanged: subagent rows of families without a registered worker are now served on demand from the spawn ledger.
- Session disposal no longer blocks on the final trace upload (uploads finish detached; daemon exit, update restarts, and worker archive-and-shutdown drain them through a single barrier), and deleting an RLM subagent no longer writes a kernel snapshot that the deletion sweep removes right away.

## [0.8.1] - 2026-08-26

- Fixed syntax highlighting in the expanded python tool-call view: triple-quoted strings spanning multiple lines now keep their string color instead of only the first line.
- Changed the default RLM maximum recursion depth for new sessions from 1 to 2.
- Changed ACP prompt requests to resolve only after all causally admitted subagent and parent work has settled.
- Changed the Cloudflare AI Gateway default model to claude-sonnet-4.5 after the catalog dropped the gateway's workers-ai mirror ids.
- Fixed ACP assistant chunks to identify message boundaries across autonomous turns.

## [0.8.0] - 2026-08-21

- Fixed an OAuth login that finishes after its server was retargeted arming the old-endpoint token against the new URL: credentials are endpoint-bound at issuance, and the host and kernel only use a token bound to the configured endpoint. **Breaking**: generic MCP OAuth credentials stored before this release lack the binding and require one `/mcp login <server>`.
- Fixed `mcp add` keeping a stored `mcp:<name>` credential when the entry was new: any add now drops the name's credential, so tokens for authored non-catalog skills (e.g. slack) cannot replay to a user-configured URL.
- Fixed kernel MCP shutdown budgets exceeding the host's kill deadline; graceful close now finishes inside it, and a kernel that exits without a `shutdown_reply` no longer stalls shutdown for the full deadline.
- Fixed a shutdown race that could leave an MCP server process running after its generation was dropped from the registry.
- Fixed the kernel MCP regression test and the Python runtime tests not running in CI.
- Fixed first IPython calls after an upgrade failing with a raw "Operation was not possible or timed out": kernel startup now tolerates cold venv boots (30s budget; crashes still fail fast via the exit handler), and zmq socket-teardown rejections surface as actionable retriable kernel errors.
- Fixed headless completion reporting a clean finish when a post-compaction continuation failed to start: ACP and print-mode idle waiters now see the failure, while interactive idle behavior is unchanged.
- Added a pre-imported generic MCP API and shell/TUI commands to manage persistent Streamable HTTP and stdio servers in user settings.
- **Breaking**: removed the documented catalog-name override — an `mcpServers` entry named after a built-in integration (e.g. `linear`) no longer repoints the built-in at a custom `url`/`bearerTokenEnvVar`; it now disables the built-in skill and is not served by the generic runtime. Rename the entry (e.g. `linear-proxy`) to keep using a custom endpoint via the generic API. This closes a credential-replay surface where name-keyed tokens could be sent to an override URL.
- Fixed agents overlooking enabled generic MCP connections by advertising their names and pre-imported `mcp` API usage in the system prompt.
- Fixed `/mcp` management feedback disappearing during resource reload and limited server details in TUI output to names and transports.
- Fixed credentials configured as env var names resolving to the literal variable name when the variable is set but empty; an empty env var now reports a missing credential ([#1468](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1468)).
- Fixed ACP rejecting an immediate follow-up prompt when injected work restarted the session; follow-ups now queue behind in-flight work, and cancellation drops queued follow-ups before they start.
- Added correlated ACP terminal-quiescence metadata, resident session settlement, and fail-closed daemon input fencing; prevented recovery state from persisting runtime credentials or model configuration.
- Fixed explicit RLM child deletion leaving hidden unsettled work after runtime teardown, including reporting cleanup failures and notifying the parent when deletion completes.
- Added changelog fragments (`packages/<pkg>/.changes/*.md`) with a CI check and release-time aggregation, eliminating `[Unreleased]` merge conflicts.
- Fixed the queued-message browse controls (Option+Up) rendering in the same style as typed prompt text inside the input box; the header is now dimmed like other hints so it cannot be mistaken for part of the prompt.
- Fixed IPython kernels and forkserver processes outliving their owner after a hard crash: kernels now arm ipykernel's parent-death poller via JPY_PARENT_PID, the forkserver watches its parent pid, and both pids are registered in the orphan process journal for supervisor recovery.
- Fixed a pid-reuse race for forked IPython kernels: signaling and liveness now go through the forkserver (the kernels' parent) instead of raw pid operations from Node, and the orphan journal's inactive record is only written on a confirmed kill outcome.
- Added session-scoped ACP MCP servers through the kernel MCP program API ([#1378](https://github.com/PrimeIntellect-ai/prime-agent/pull/1378) by [@hallerite](https://github.com/hallerite)).
- Changed the subagents summary under the prompt into a bordered `agents` tile with color-coded running/idle/inactive counts and a right-aligned open hint.
- Enabled `/fast` with OpenAI API-key authentication for GPT-5.4/GPT-5.5/GPT-5.6 and updated the unavailable message ([#1595](https://github.com/PrimeIntellect-ai/prime-agent/discussions/1595)).
- Fixed `/goal` re-prompting a parent that had correctly delegated to subagents and ended its turn: the continuation now waits until descendant work settles, then resumes automatically.
- Changed post-compaction continuation error classification to typed `AgentContinueError` codes instead of matching error message text.
- Fixed the working-status elapsed timer (e.g. "Waiting · 5s") restarting at 0s after leaving and re-entering a session or re-attaching to it; the timer is now anchored to the in-flight turn's user message and keeps counting.
- Added a `session_before_refine` extension hook: extensions can replace `/refine` and auto-refine planning with their own proposal (for example using a cheaper model — see `examples/extensions/custom-refinement.ts`) or skip a refinement round; rollbacks bypass the hook and extension edits go through the normal apply-time validation. Also documents `refine_complete`.
- Added a durable `[refinement]` transcript message after each refinement showing the applied harness edits (expandable to exact before/after diffs via the shared tool-output toggle), and a live loader while a user-issued /refine runs.
- Fixed the Agents View heartbeat refresh failing entirely ("Cannot list heartbeats while session worker is failed") when any resident worker was terminally failed: failed workers are now excluded from the global catalog while recovering and disconnected workers still fail closed.
- Refreshed MCP providers immediately after server changes so OAuth connections can be started without restarting Prime Agent.

## [0.7.4] - 2026-08-19

- Fixed model searches ranking stronger matches ahead of weaker signed-in matches while preferring signed-in providers for equivalent results ([#539](https://github.com/PrimeIntellect-ai/prime-agent/pull/539) by [@eliebak](https://github.com/eliebak)).
- Fixed large IPython variables repeatedly slowing later turns by excluding them from persistent snapshots and removing them when context is compacted.
- Fixed daemon socket paths being used verbatim in identity derivations: on supported platforms, `--daemon-socket` spellings differing only by duplicate or trailing slashes now normalize to one canonical path, so worker-descriptor namespaces, daemon log files, and persisted descriptors agree.
- Added a `thinking` option to `rlm.run` for spawning subagents with an explicit reasoning level; invalid levels for the resolved child model fail spawn.
- Changed opening the agents view (full or scoped) with a draft prompt to auto-stash the draft instead of refusing; the draft is restored into the editor when the session is reopened.
- Fixed Shift+Enter no longer inserting a newline in terminals that send a literal `\n` (for example a Ghostty `shift+enter=text:\n` mapping): the byte decoded as `ctrl+j` and triggered the new edit-diff toggle instead of the editor newline.
- Removed a system prompt paragraph referring to an async `bash()` kernel helper and managed jobs that do not exist in the runtime.
- Changed RLM guidance to orchestrate independent workers in parallel, use available async shell helpers safely, end the turn instead of sleeping, polling, or blocking on long awaits, provide proactive outcome-focused progress updates from root agents, and use simplified technical English for user-facing prose.
- Fixed new top-level daemon sessions inheriting an RLM child depth from the supervisor process.
- Fixed active goals stalling after a mid-goal automatic compaction when the previous continuation prompt was already running: only undelivered continuations deduplicate, so a fresh continuation is queued instead of being suppressed.

## [0.7.3] - 2026-08-17

- Fixed assistant rendering when provider payloads contain null or sparse content blocks.
- Added authenticated host-request contracts with per-call request IDs, generation fencing, cancellation signals, and currentness checks.
- Fixed root daemon shutdown retaining cleanup ownership while kill events are in flight.
- Changed RLM family discovery to use a daemon-owned append-only spawn ledger with per-child display metadata instead of reconstructing topology from session files.
- Fixed long-running macOS supervisors losing ownership when system cleanup removed authority records from `$TMPDIR`.
- Fixed deleted RLM children leaking kernel snapshots while retaining their readable transcript tombstones.
- Changed Agents View subagent rows to show stable `name · model/effort · summary` metadata.
- Changed the default Cerebras model to the available `gpt-oss-120b` route and aligned cross-provider handoff fixtures with the generated catalog.
- Fixed the agent going silent after an automatic context compaction interrupted unfinished work: the tool loop now resumes when a threshold compaction fails or is skipped, and active goals keep continuing after a successful mid-goal threshold compaction.
- Changed the agents view splash hint from "type to start" to "type to search sessions".
- Added `app.edits.expand` (`ctrl+j`) to toggle edit diffs; diffs are now shown only by this toggle, and `ctrl+o` no longer affects them.
- Changed edit rendering so the `╰─ <path> +N -M` summary line is always visible and `ctrl+j` toggles the diff inline beneath it, indented to the summary text.
- Fixed fullscreen wheel scrolling in Ghostty while retaining application link clicks; set `terminal.fullscreenMouse` to `false` to use native Cmd-click instead.
- Changed the agents view to sort idle and inactive sessions by last message time, newest first, while keeping running agents in stable creation order.
- Fixed `openai-codex` models being invisible to `rlm` subagents and `find_models` because model discovery reported Prime Agent's own version as the Codex client version ([#1375](https://github.com/PrimeIntellect-ai/prime-agent/pull/1375) by [@bilelrais](https://github.com/bilelrais)).
- Added a working hint that recommends sharing traces with Prime Intellect to help train open-source LLMs.
- Restored bare `prime-agent --resume` opening the agents view and the `/resume [id|path]` slash command; bare commands open the agents view and an argument resumes that session in place.
- Fixed URLs not opening on click in fullscreen mode on terminals such as Ghostty; clicking a link in the transcript, dock, or overlays now opens it in the browser.
- Fixed ctrl+p ("Toggle agent message expansion") only toggling received agent messages; it now expands and collapses sent agent messages together with received ones.

## [0.7.2] - 2026-08-11

- Fixed Down Arrow focusing the Agents View entry before moving a nonempty prompt cursor to the end ([ENG-5147](https://linear.app/primeintellect/issue/ENG-5147/keep-down-arrow-in-the-prompt-until-the-cursor-reaches-the-end)).
- Added `app.messages.expand` (`ctrl+p`) to collapse or expand agent-to-agent messages separately from `ctrl+o` tool output.
- Added a `ctrl+t` expand hint to collapsed thinking blocks, matching the tool output hint.
- Changed expand/collapse hints to a consistent bracketed `(Ctrl+O to expand)` style across tool, message, summary, and error rows.
- Added a configurable copy action to login dialogs so raw sign-in URLs can be copied without selecting wrapped text ([#643](https://github.com/PrimeIntellect-ai/prime-agent/issues/643)).
- Added privacy-safe pseudonymous product analytics for onboarding, command use, execution modes, run outcomes, TTFT, latency, usage, tools, retries, and compactions, with disclosure and opt-out controls ([ENG-4682](https://linear.app/primeintellect/issue/ENG-4682/add-privacy-safe-posthog-analytics-to-prime-agent)).
- Changed sent agent messages in the IPython cell UI to show only the message text with a `╰─` gutter when expanded, matching received messages, and hid the raw `agent_message.send` receipt dictionary.
- Fixed Homebrew installs attempting to self-update their versioned Cellar keg instead of directing users to `brew upgrade prime-agent` ([#844](https://github.com/PrimeIntellect-ai/prime-agent/issues/844))
- Fixed the agents view collapsing expanded subagent lists when returning from an opened agent ([ENG-5105](https://linear.app/primeintellect/issue/ENG-5105/keep-the-agents-view-state-persistent)).
- Kept the subagent summary row visible and selectable while its list is expanded in the agents view, so pressing enter on it collapses the list again ([ENG-5105](https://linear.app/primeintellect/issue/ENG-5105/keep-the-agents-view-state-persistent)).
- Added in-place editing of queued steering and follow-up messages: Alt+Up/Alt+Down browse the queue from the draft, Enter applies the edit as steering, Alt+Enter as a follow-up, and submitting an empty editor deletes the item; interrupts now preserve the queue ([#838](https://github.com/PrimeIntellect-ai/prime-agent/pull/838)).
- Fixed workers with no live connection reporting as `ready`; stopping workers now report a `stopping` state, are hidden from live sessions, and no longer receive daemon-wide commands ([#850](https://github.com/PrimeIntellect-ai/prime-agent/pull/850)).
- Fixed timed-out worker stops stranding dead-but-registered workers ("Session worker is not connected"); stops now finalize in the background once the process exits, and zombie processes are no longer counted as alive ([#851](https://github.com/PrimeIntellect-ai/prime-agent/pull/851)).
- Fixed sessions becoming permanently unopenable after a stale worker registration was left behind; open/resume now self-heals by finishing the old cleanup and starting a fresh worker ([#852](https://github.com/PrimeIntellect-ai/prime-agent/pull/852)).

## [0.7.1] - 2026-08-07

- Fixed the bundled `websearch` skill description and missing-key guidance omitting the `/login` → **MCP Connections** step required to configure Serper.
- Fixed `retry_worker` cancelling its own recovery when a stopped session worker left a saved stop marker behind, leaving the session stuck at "Session worker is not connected".

## [0.7.0] - 2026-08-05

### Breaking Changes

- Changed agent messages to always use steering delivery and removed delivery-mode options from the Python, CLI, RPC, and connection APIs. Code passing `mode` to `agent_message.send`, or a delivery mode over the CLI/RPC, must drop it.

### Changed

- Changed self-updates to report the previous and new Prime Agent versions.

### Fixed

- Fixed the subagent summary showing retained children as idle while they run follow-up work.

## [0.6.1] - 2026-08-05

- Added reverse tab navigation to the `/login` configuration menu and moved the model scope shortcut to `Alt+S`.
- Fixed daemon startup crashes hiding their exit status and daemon log until the startup timeout.
- Documented the global `idleEvictionMinutes` daemon setting, including its default, valid values, and eviction/passivation behavior ([#621](https://github.com/PrimeIntellect-ai/prime-agent/issues/621)).
- Fixed top-level `--help` omitting `acp` from the supported `--mode` values ([#620](https://github.com/PrimeIntellect-ai/prime-agent/issues/620)).
- Fixed `stop` and `rename` becoming prompts when `--daemon-socket` precedes the command ([#622](https://github.com/PrimeIntellect-ai/prime-agent/issues/622)).
- Fixed subagent terminal notices arriving as anonymous follow-up prompts instead of attributed agent messages, so a parent can now tell which child reported completion, failure, or cancellation, and a busy parent is steered at the next turn boundary rather than waiting to go idle ([#617](https://github.com/PrimeIntellect-ai/prime-agent/issues/617)).
- Fixed ACP mode reporting a failed turn as a clean `end_turn`. A provider error, expired auth, or unusable model left `session/prompt` resolving with no updates at all, which reads to a client as a successful but empty turn; the turn now fails with the underlying error instead.
- Fixed ACP cwd mismatch metadata treating symlink aliases such as macOS `/var` and `/private/var` as different directories ([#623](https://github.com/PrimeIntellect-ai/prime-agent/issues/623)).

## [0.6.0] - 2026-08-04

### Breaking Changes

- Changed `rlm(...)` to return at task admission instead of waiting for the child to finish. It now yields a spawn handle (`rlm_child_id`, `name`, `session_dir`, `model`); `RLMResult` and its final answer, usage, and model-fallback warning are gone. A child reports back with `agent_message.send(..., receiver_role="parent")`, which arrives as an ordinary prompt and starts a parent turn. Code that read `result.answer`, or treated `asyncio.gather(...)` over `rlm(...)` as fan-in, must be updated.
- Changed `agent_message.send` to role-addressed delivery: pass `receiver_role` (`"parent"`, `"sibling"`, `"child"`) plus `receiver_name` for siblings and children. The old positional `send(target, message)` form no longer works, and the separate `roster()` call is now `agent_message.list_agents()`.
- Narrowed agent reach to the nuclear family: an agent may message or observe only its parent, siblings, and direct children. Top-level sessions are siblings of one another, so agent-to-agent between them still works; grandchildren and cousins must be reached by relaying through the intermediate child. Users are unaffected and still see every session.
- Requesting an unavailable subagent model now fails the spawn instead of silently falling back to the parent's model with a warning.
- Bumped the daemon schema revision to 13 for the parent-edge, depth, naming, and passivation wire changes; older clients and daemons are rejected cleanly at connect.

### Added

- Added `--mode acp`: Prime Agent now runs as an [Agent Client Protocol](https://agentclientprotocol.com) agent over NDJSON on stdio, driving an `AgentConnection` in-process. IPython surfaces as an ACP `execute` tool call carrying its cell source, and capabilities ACP has no native concept for (subagents, autonomous gate state, rich IPython output, compaction, goals, heartbeats, continual-harness refinement) travel in a namespaced `ai.primeintellect.prime-agent` `_meta` envelope that vanilla ACP clients ignore. Documented in `docs/acp.md`.
- Added `/rlm-max-depth` to view or set the recursion cap for the current chat, with `--global` to change the default for new sessions.
- Added recursive navigation to the agents view: drill into any session's children and back out again, with each chat showing its own depth.
- Added a family roster via `agent_message.list_agents()`, listing parent, siblings, and children with name, id, depth, and status, including family members currently on disk.
- Added sibling-unique agent names, enforced at spawn and rename against loaded and unloaded sessions alike. The same name may be reused at different depths.
- Added an `idleEvictionMinutes` setting (default 90, `off` to disable) controlling idle eviction and passivation.

### Changed

- Changed finished subagents to stay on disk until something touches them, so memory scales with the active frontier rather than every subagent ever spawned. Lists show them without loading them, and attach, message, or transcript read wakes them on demand.
- Changed sessions to persist their parent edge and derived RLM depth, so tree position no longer has to be inferred from whatever happens to be in memory.
- Changed the supervisor to stop worker processes whose whole session tree has been idle past the threshold, and to passivate individually idle children inside still-busy workers.
- Replaced the child-agent inspector with a single subagent summary line under the prompt that opens the agents view scoped to that session's children.

### Fixed

- Fixed `stop` and `rename` rejecting custom daemon socket options.
- Fixed SIGINT in print mode leaving the session active until liveness reclaim.
- Fixed daemon startup failing permanently when an interrupted supervisor owner directory contained only stray files.
- Fixed agents-view fallback notices and scoped live sessions surviving transient refresh failures across chat returns.
- Fixed stopping completed subagents deleting their retained sessions.
- Fixed silent or cancelled RLM children leaving parents without a terminal status notice.
- Added missing argument hints to `/name`, `/model`, `/export`, and `/import` in autocomplete.

## [0.5.1] - 2026-08-04

### Fixed

- Fixed `/refine` failing with an opaque JSON parse error when the refiner exceeded a fixed 4096-token output cap; output budgets now derive from the selected model, and a truncated reply reports the exhausted budget directly.

## [0.5.0] - 2026-08-03

### Breaking Changes

- Reworked session input scheduling into a single session action lifecycle and store (daemon protocol 7, schema revision 8); older clients and daemons are rejected cleanly at connect.

### Changed

- Changed large daemon session loads to stream JSONL history and avoid retaining a second full-file copy in memory.
- Changed the agents view to render explicit session names in bold and the "(no messages)" placeholder in italics.
- Changed subagent guidance to retain reusable children and delete completed direct children once they are no longer needed.
- Changed top-level CLI help and documentation to expose autonomous mode, quality gates, and their limits.
- Changed daemon and RPC session state to report literal queued actions separately from active scheduler work.

### Fixed

- Fixed the blank line between the recap and the working hint so they render directly above each other.
- Fixed compaction retaining runtime resources after an explicitly deleted subagent had a transient cleanup failure.
- Fixed long-running thinking timers to display hours and days instead of unbounded minutes.
- Fixed overlapping daemon snapshot catch-ups closing healthy workers and preventing new sessions from starting.
- Fixed active scheduler work being reported as queued in session state.
- Fixed headless runs completing before queued follow-up work had finished.
- Fixed `/compact` consuming itself as its own successor action.
- Fixed daemon parse rejections dropping the command id, which left older clients waiting for a timeout instead of seeing the protocol error.
- Fixed `--goal` sessions never showing the objective to the model, which made seeded goals invisible to first turns and continuations.

## [0.4.0] - 2026-08-01

### Breaking Changes

- Replaced the recursive daemon `get_session_tree` response with flat nodes linked by `parentId` (protocol 6); clients must support the new response shape.
- Removed `/resume` and bare `--resume`; browse sessions with left-arrow from a daemon chat, or use `--resume <session-id|path>` for a direct resume.

### Added

- Added `ctrl+n` to start a session from Agents View, and `alt+enter` to queue a reply as a follow-up while Enter steers a streaming session.
- Added session-owned `/compact`, `/refine`, `/goal`, and `/autonomous` commands with autocomplete to the Agents View reply composer, plus target-scoped `/name` and `/kill` commands.
- Added optional stable session names and initial prompts to `/new`.

### Changed

- Changed collapsed edit and IPython calls to show compact per-file line-change summaries while retaining full expanded diffs.
- Changed bare `/effort` to open a selector of the current model's supported reasoning levels, and removed token estimates from reasoning-effort displays.
- Improved session search ranking to prefer exact session-name and first-message matches before prefix, substring, and transcript fuzzy matches.

### Fixed

- Fixed deeply nested `/tree` sessions overflowing the daemon serializer by transferring and rebuilding the session tree iteratively.
- Fixed `prime-agent agents` opening a new chat for a process-local session.
- Fixed daemon startup after an interrupted supervisor leaves an empty ownership directory.
- Fixed `/effort xhigh` and `/effort max` being rejected before a model is active.
- Fixed IPython tracebacks emitting ANSI color codes.
- Fixed selected rows and selectors becoming nearly invisible on terminals whose background matches the selected theme color.
- Fixed startup waiting on private Prime Inference model authorization by caching authorization locally and refreshing stale entries in the background.

## [0.3.3] - 2026-07-23

- Removed the bundled orchestration heartbeat skill from the model system prompt.
- Fixed feature hints crowding queued messages and side questions by placing them below the recap and hiding them while messages are queued ([ENG-4741](https://linear.app/primeintellect/issue/ENG-4741/recap-queuefollow-upmessage-hint-looks-cluttered)).
- Fixed `/btw` truncating long answers by rendering side questions in the scrollable transcript.
- Changed recognized slash commands to retain accent coloring after submission in live, replayed, and queued TUI surfaces while preserving Markdown arguments.
- Unified prompt, steering, follow-up, and session-command scheduling under session-owned admission with durable queue state and coordinated update/restart checkpoints.
- Unified Agents View and session resume into one searchable Running/Idle/Inactive session view with live heartbeat badges.
- Changed selection cursors from `→` to `›` across model selectors, scoped-models, and the theme default for consistency with tree and user-message selectors.
- Changed the queued follow-up hint connector from `↳` to `╰─` to match the tool-execution continuation connector.
- Changed `/context` tree connectors from `├ `/`└ ` to `├─ `/`└─ ` to match the tree selector and session picker.
- Changed the IPython cell queued marker from `▸` to `◇` to match the subagent and context-tree status icons.
- Changed slash-command autocomplete to separate argument hints and resource provenance, show only the selected command description, and summarize hidden results directionally.
- Fixed cancelled extension commands remaining alive when spawned processes ignored SIGTERM ([#458](https://github.com/PrimeIntellect-ai/prime-agent/pull/458) by [@snimu](https://github.com/snimu)).
- Fixed OAuth browser launch URLs being interpreted by the system shell.
- Added agent-callable `refine` skill so the model can schedule continual harness refinement from IPython via `await refine.run()` without blocking the current turn ([#504](https://github.com/PrimeIntellect-ai/prime-agent/pull/504) by [@sethkarten](https://github.com/sethkarten)).
- Changed long live session opens to render a bounded recent transcript tail while preserving full prompt history ([#343](https://github.com/PrimeIntellect-ai/prime-agent/pull/343) by [@sethkarten](https://github.com/sethkarten)).
- Changed `/refine` to run planning in the background so the conversation is not blocked during the LLM pass ([#497](https://github.com/PrimeIntellect-ai/prime-agent/pull/497) by [@sethkarten](https://github.com/sethkarten)).
- Added serialized headless refinement and `--goal` / `--goal-token-budget` for seeding durable session goals ([#514](https://github.com/PrimeIntellect-ai/prime-agent/pull/514) by [@sethkarten](https://github.com/sethkarten)).
- Added multi-turn `/btw` side conversations with transient in-pane bash commands ([#512](https://github.com/PrimeIntellect-ai/prime-agent/pull/512) by [@ilijalichkovski](https://github.com/ilijalichkovski)).


## [0.3.2] - 2026-07-20

- Fixed invalid `--resume` session IDs being submitted as prompts, with nearest-session guidance instead ([ENG-4722](https://linear.app/primeintellect/issue/ENG-4722/prime-agent-resume-accepts-incorrect-session-ids)).
- Changed `/model` to show all public models with authenticated providers first and open provider authentication when an unavailable model is selected ([ENG-4575](https://linear.app/primeintellect/issue/ENG-4575/show-all-models-in-model-and-prompt-auth-on-selection)).
- Changed the shared configuration menu to cycle tabs with Tab, use Shift+Tab for model scope, show an Escape close hint, preserve arrow-key search editing, and remove the model selector's provider shortcut.
- Fixed searchable selectors retaining their previous scroll position after the query changed.
- Changed interactive, print, JSON, RPC, piped-stdin, and no-session clients to use the same daemon-owned runtime while preserving their existing commands, output protocols, and lifecycle behavior ([ENG-4685](https://linear.app/primeintellect/issue/ENG-4685)).
- Added RPC controls for schedules, heartbeats, agent messaging, and live session observation ([ENG-4685](https://linear.app/primeintellect/issue/ENG-4685)).
- Fixed daemon-backed headless startup, rollback routing, RPC wire compatibility, and duplicate client runtime preparation ([ENG-4685](https://linear.app/primeintellect/issue/ENG-4685)).
- Fixed heartbeat-owning subagents appearing completed, showing completion checkmarks below the prompt, being omitted from active subagent counts, or remaining visible after deletion.
- Fixed the heartbeat tray and manager showing heartbeats from unrelated sessions.
- Fixed daemon backpressure triggering redundant catch-up snapshots for events already queued by the socket.
- Added dedicated stable and beta installers, with stable advancing on version bumps and beta advancing on every commit to `main`.
- Fixed incompatible daemon builds crashing startup or respawning after shutdown, with capability negotiation, verified provenance, and convergent force shutdown ([ENG-4687](https://linear.app/primeintellect/issue/ENG-4687/make-daemon-version-mismatches-self-healing)).
- Changed tool-result and announcement images to show compact metadata instead of terminal graphics ([#437](https://github.com/PrimeIntellect-ai/prime-agent/pull/437) by [@snimu](https://github.com/snimu)).
- Changed top-level CLI help to show concise common options and commands without loading runtime resources ([ENG-4688](https://linear.app/primeintellect/issue/ENG-4688/help-command-is-obscenely-verbose)).
- Fixed completed subagents cancelling their RLM heartbeats before the first run ([ENG-4652](https://linear.app/primeintellect/issue/ENG-4652/subagent-heartbeats-dont-work)).
- Changed the fullscreen follow shortcut from `Alt+Down` to `Ctrl+Shift+Down` for more reliable terminal input ([ENG-4684](https://linear.app/primeintellect/issue/ENG-4684/altdown-doesnt-work)).
- Added user-requested model selection for subagents with bounded account-authorized discovery and explicit parent-model fallback warnings ([ENG-4649](https://linear.app/primeintellect/issue/ENG-4649/allow-subagents-to-use-a-different-model-than-the-parent-agent)).
- Added subtle feature hints to longer-running agent turns ([ENG-4521](https://linear.app/primeintellect/issue/ENG-4521/add-subtle-hints-for-new-prime-agent-features)).
- Fixed active heartbeats not resuming after Prime Agent updates ([ENG-4657](https://linear.app/primeintellect/issue/ENG-4657/heartbeats-dont-survive-updatesdaemon-reboots)).
- Fixed the Agents View reordering sessions whenever prompts or heartbeats updated their activity timestamps ([ENG-4650](https://linear.app/primeintellect/issue/ENG-4650/agents-view-shifts-session-list-constantly)).
- Added parent-scoped subagent lifecycle APIs: create children with readable default or orchestrator-chosen names, recover running or completed children through `rlm.list_subagents()`, continue them through agent messaging, and close/remove them with `rlm.delete_subagent()`.
- Changed shell commands to use discoverable agent, schedule, package, model, session, update, doctor, and full-shutdown verbs without exposing the background daemon hierarchy ([ENG-4538](https://linear.app/primeintellect/issue/ENG-4538/standardize-bash-command-conventions-and-improve-command-discovery)).
- Fixed unsupported Node versions crashing before startup by requiring Node 22.8.0 or newer and showing upgrade guidance before loading the CLI ([ENG-4260](https://linear.app/primeintellect/issue/ENG-4260/incorrect-node-version-breaks-first-launch)).
- Added `@` file-path autocomplete to new-agent and reply prompts in the Agents View.
- Fixed slow daemon clients becoming stuck when newer session snapshots arrived during catch-up.
- Fixed queued messages getting stranded when an agent turn ended ([ENG-4653](https://linear.app/primeintellect/issue/ENG-4653/queued-messages-can-get-stuck-with-heartbeats)).
- Changed `/traces upload-all` to pace requests within the platform rate limit, honor bounded `Retry-After` responses, and support interruption.
- Fixed resuming a daemon-resident session to attach the requesting client to its existing worker without disturbing other clients ([ENG-4656](https://linear.app/primeintellect/issue/ENG-4656/resuming-prime-agent-sessions-should-attach)).
- Fixed daemon-owned updates terminating their updater before the daemon restart and session restore completed ([ENG-4606](https://linear.app/primeintellect/issue/ENG-4606/benign-error-on-prime-agent-update)).
- Fixed first-launch Prime login and kept onboarding visible between team and model selection ([ENG-4658](https://linear.app/primeintellect/issue/ENG-4658/fix-onboarding-login-enter-key-and-model-selector-flicker)).
- Fixed active heartbeat sessions appearing under Needs Input or Completed instead of a dedicated Heartbeats section ([ENG-4654](https://linear.app/primeintellect/issue/ENG-4654/categorize-heartbeat-sessions-as-working)).
- Fixed stashed prompts being lost when leaving and reopening a session from the Agents View ([ENG-4659](https://linear.app/primeintellect/issue/ENG-4659/stashed-prompts-should-persist)).
- Added a combined heartbeat indicator and manager for pausing, resuming, or stopping user and agent heartbeats ([ENG-4536](https://linear.app/primeintellect/issue/ENG-4536/add-heartbeat-observability-and-management-ui)).

## [0.3.1] - 2026-07-15

- Added `/fast` for OpenAI Fast mode on supported ChatGPT models ([ENG-4620](https://linear.app/primeintellect/issue/ENG-4620/add-support-for-gpt-fast-mode-maybe-fast)).
- Changed wrapped diff rows to use a blank hanging gutter.
- Fixed team-gated Prime Inference routes being missing from model selectors by merging the authenticated team catalog during model refresh ([ENG-4645](https://linear.app/primeintellect/issue/ENG-4645/internalglm-52-fast-isnt-working)).
- Added confirmation when fullscreen text selection copies to the clipboard ([ENG-4644](https://linear.app/primeintellect/issue/ENG-4644/copy-issues)).
- Added an agent-run edit total above the recap.
- Changed edit tool calls to always show full diffs while keeping IPython source collapsed until Ctrl+O expands it.
- Changed tool expansion hints to appear only on the latest tool row instead of every tool call ([ENG-4583](https://linear.app/primeintellect/issue/ENG-4583/too-many-ctrlo-alerts)).
- Changed IPython kernels to set `NO_COLOR=1`, preventing ANSI color escapes from inflating `%%bash` output.
- Fixed update restarts starting concurrent daemon supervisors or unlinking a replacement supervisor's socket ([ENG-4600](https://linear.app/primeintellect/issue/ENG-4600/prevent-concurrent-daemon-supervisors-after-update-restart)).
- Fixed worker recovery races and made daemon shutdown-all converge across hidden supervisors ([ENG-4603](https://linear.app/primeintellect/issue/ENG-4603/serialize-worker-recovery-and-make-shutdown-all-converge)).
- Changed provider, model, and MCP setup to use one tabbed configuration menu ([ENG-4539](https://linear.app/primeintellect/issue/ENG-4539/unify-providers-models-and-mcp-connections-menu)).
- Changed the shared configuration menu to show prominent, responsive tabs with configurable navigation shortcuts ([ENG-4534](https://linear.app/primeintellect/issue/ENG-4534/make-login-tabs-more-obvious)).
- Fixed IPython edit diffs replacing syntax highlighting with a single foreground color ([ENG-4616](https://linear.app/primeintellect/issue/ENG-4616/syntax-highlighting-is-overridden-in-diff-view)).
- Fixed Prime Inference login leaving new sessions without a persisted model selection ([ENG-4573](https://linear.app/primeintellect/issue/ENG-4573/prompt-for-model-selection-after-prime-inference-login)).
- Fixed empty prompt placeholders hiding the input caret.
- Fixed automatic model selection preferring other configured providers over Prime Inference's GLM 5.2 default.
- Fixed missing ripgrep blocking subagents and added actionable installation guidance for the optional search helper ([ENG-4572](https://linear.app/primeintellect/issue/ENG-4572/ripgrep-not-installed)).
- Removed the shared worker snapshot spill cache to prevent concurrent workers from deleting each other's snapshot chunks ([ENG-4601](https://linear.app/primeintellect/issue/ENG-4601/remove-shared-worker-snapshot-spill-cache-directories)).
- Fixed narrow slash-command descriptions ending abruptly or clearing the prompt background, and added a content-sized popup above the input with the same distinct surface as `/btw` ([ENG-4542](https://linear.app/primeintellect/issue/ENG-4542/command-descriptions-are-cut-off-on-narrow-screens)).
- Fixed snapshot transfers terminating resident workers, stranding partial readers, or rejecting identical retries ([ENG-4602](https://linear.app/primeintellect/issue/ENG-4602/make-snapshot-transfers-idempotent-and-non-fatal)).
- Fixed the resume picker opening on an older session instead of the newest session ([ENG-4630](https://linear.app/primeintellect/issue/ENG-4630/show-latest-sessions-first-in-resume-list)).
- Fixed tool-only responses rendering directly against the preceding user prompt.

## [0.3.0] - 2026-07-13

- Changed daemon and headless execution to isolate each root session tree in a recoverable worker process, with protocol-v2 chunked snapshots, compact streaming, attachment-local backpressure, session leases, and unchanged print, JSON, and RPC interfaces.
- Added autonomous mode with host-side continuations, configurable limits, and quality gates for evaluator-controlled runs ([#278](https://github.com/PrimeIntellect-ai/prime-agent/pull/278) by [@sethkarten](https://github.com/sethkarten)).
- Added `/traces preview` and `/traces upload-all` for inspecting the current payload and backfilling saved parent and subagent traces.
- Changed `/traces upload` and `/traces upload-all` to be explicit one-shot uploads that do not enable automatic sharing.
- Changed trace uploads to retry transient network and HTTP failures with bounded exponential backoff and jitter.
- Fixed Prime Inference credential and team-header precedence to prefer `PRIME_API_KEY`, then the Prime CLI config, then `auth.json`.
- Fixed aborted autonomous gates leaving detached process trees and supervisor recovery retaining intentionally stopped workers after stale scheduler locks.
- Fixed supervisor replacement surfacing fatal socket errors or recovering roots that were intentionally stopped ([ENG-4526](https://linear.app/primeintellect/issue/ENG-4526/reconnect-daemon-clients-transparently-after-supervisor-replacement)).
- Fixed daemon catch-up snapshots being disposed mid-transfer or triggering resets that cleared drafts, local queues, dialogs, active UI state, or in-flight reasoning traces.
- Fixed compact daemon streams occasionally duplicating the first token of an assistant response.
- Fixed subagent prompts and usage counters flickering or disappearing during daemon resyncs and large parallel runs, and added compact fixed-width recap rows.
- Fixed stale heartbeat jobs reopening sessions after they were archived, deleted, explicitly shut down, concurrently terminated, or lost resident worker ownership ([ENG-4519](https://linear.app/primeintellect/issue/ENG-4519/heartbeats-rebirth-sessions-that-were-previously-killed)).
- Fixed heartbeat starvation by moving durable schedules into per-session artifacts and running them concurrently in their owning resident workers, independent of supervisor replacement ([ENG-4527](https://linear.app/primeintellect/issue/ENG-4527/dispatch-heartbeats-concurrently-across-isolated-session-workers)).

## [0.2.9] - 2026-07-13

- Changed tool call groups to use one blank row above and below without blank rows between consecutive calls.
- Changed the session tree to show only user messages by default.
- Changed agent-to-agent messages to render as directional rows, with received messages expandable in chat and sent messages shown below their Python cell ([ENG-4531](https://linear.app/primeintellect/issue/ENG-4531/collapse-and-simplify-agent2agent-messages-in-chat-tui)).
- Fixed IPython state restore notices rendering as full user messages when prompts were queued or restored ([ENG-4530](https://linear.app/primeintellect/issue/ENG-4530/collapse-ipython-state-restore-messages-in-chat-tui)).
- Changed bare `/mcp` to open the Services menu while preserving explicit `list`, `login`, and `logout` subcommands ([ENG-4535](https://linear.app/primeintellect/issue/ENG-4535/open-services-mcp-menu-from-mcp)).
- Added `/btw` and `/side` for one-turn inline side questions that use the current context without changing the main session ([ENG-4509](https://linear.app/primeintellect/issue/ENG-4509/add-btw-and-side-side-question-flows)).
- Changed scheduled heartbeat prompts to steer (interrupt the current turn) by default, with a `steer`/`follow_up` delivery mode selectable via `/heartbeat --steer|--follow-up` and the `rlm_heartbeat` skill's `delivery_mode` argument.
- Changed the new-chat splash to show only version, model, and cwd metadata and rotate among five example prompts.
- Fixed self-updates losing restored daemon sessions to a socket cleanup race and leaving open session or agents-view windows disconnected.
- Changed daemon connection errors to report the failed operation, session identity, recovery steps, socket, and diagnostic log instead of raw protocol reasons.
- Changed the Agents View and new-chat splashes to keep one blank row above the butterfly.
- Fixed Agents View retrying after an intentional daemon shutdown instead of stopping with restart guidance.
- Fixed stale heartbeat jobs reopening archived, deleted, or concurrently terminated sessions ([ENG-4519](https://linear.app/primeintellect/issue/ENG-4519/heartbeats-rebirth-sessions-that-were-previously-killed)).
- Fixed onboarding blocking normal TUI use by reopening login or model selection after startup ([ENG-4537](https://linear.app/primeintellect/issue/ENG-4537/stop-onboarding-from-gating-normal-tui-use)).
- Fixed IPython Bash cells with leading blank lines being labeled and previewed as Python ([ENG-4529](https://linear.app/primeintellect/issue/ENG-4529/leading-newline-before-percentpercentbash-names-tool-call-as-python)).
- Fixed recap layout shifts by keeping the previous recap visible until its replacement arrives ([ENG-4533](https://linear.app/primeintellect/issue/ENG-4533/reserve-space-for-recap-to-prevent-layout-shift)).
- Changed the new-chat tray to hide shortcut guidance while typing and keep the `agents` link visible.

## [0.2.8] - 2026-07-09

- Added built-in Herdr integration that reports agent lifecycle state to Herdr panes automatically, without requiring `herdr integration install pi`.
- Changed Escape to interrupt active work with a visible abort notice, double Escape to open the session tree from an empty prompt or clear an idle draft, and `?` to show shortcuts ([ENG-4489](https://linear.app/primeintellect/issue/ENG-4489/rewire-prime-agent-shortcuts-to-match-claude-code-flow)).
- Changed new-chat guidance to show concise shell, command, file, and shortcut hints, with Agents View first and `? for shortcuts` after the model and effort ([ENG-4489](https://linear.app/primeintellect/issue/ENG-4489/rewire-prime-agent-shortcuts-to-match-claude-code-flow)).
- Changed `?` shortcut help to appear as a temporary compact panel below the transcript, while `/hotkeys` shows the full reference without Ctrl+Z ([ENG-4489](https://linear.app/primeintellect/issue/ENG-4489/rewire-prime-agent-shortcuts-to-match-claude-code-flow)).
- Fixed Escape repeats around autocomplete, queued draft restoration, whitespace-only drafts, and active background work ([ENG-4489](https://linear.app/primeintellect/issue/ENG-4489/rewire-prime-agent-shortcuts-to-match-claude-code-flow)).
- Fixed the agents-view splash shifting when opening an agent session ([ENG-4517](https://linear.app/primeintellect/issue/ENG-4517)).
- Changed `/model` to sort featured flagship models above a provider's long tail (with a numeric-aware alphabetical tiebreak), so the full Prime Inference catalog doesn't flood the picker.
- Fixed selector prompts and choices filling their background through the terminal's right edge.
- Changed automatic harness refinement to be enabled by default while keeping `autoRefine.enabled: false` as the opt-out.
- Fixed non-numeric `autoRefine.turnInterval` and `autoRefine.cooldownMs` settings falling back to defaults instead of silently enabling a noisy auto-refine loop.
- Fixed all session-resume entry points to share a searchable full-screen picker, stream results while loading, and support renaming ([ENG-4513](https://linear.app/primeintellect/issue/ENG-4513/resume-in-agents-view-is-broken)).

## [0.2.7] - 2026-07-08

- Changed subagent and refinement guidance to favor non-blocking subagent tasks by default, use disk-backed tracking for long-running fan-out, inspect or message live subagents when agent observation/messaging skills are available, and capture reusable delegation roles, procedures, facts, preferences, and prompt addendums with `/refine`.
- Changed `attach_image` to resize and compress large inline image attachments before storing them for rendering and replay ([#340](https://github.com/PrimeIntellect-ai/prime-agent/pull/340) by [@sethkarten](https://github.com/sethkarten)).
- Fixed heartbeat and goal continuation prompts rendering like ordinary user messages ([ENG-4482](https://linear.app/primeintellect/issue/ENG-4482/heartbeat-message-should-have-a-different-ui-from-user-message)).
- Fixed `/heartbeat` guidance to show `stop` and the `every <duration> <instruction>` interval syntax ([ENG-4484](https://linear.app/primeintellect/issue/ENG-4484/improve-heartbeat-command-syntax-guidance-in-ui)).
- Fixed Ctrl+C canceling the active turn, bash command, and IPython kernel execution deterministically, with a compact recovery prompt and model-visible reset notice when an interrupted IPython cell keeps running ([ENG-4490](https://linear.app/primeintellect/issue/ENG-4490)).
- Fixed login dialogs in fullscreen so sign-in URLs can be selected natively ([ENG-4480](https://linear.app/primeintellect/issue/ENG-4480/new-fullscreen-tui-makes-it-impossible-to-copy-login-url)).
- Fixed `/model` opening and selection staying blocked on live model refreshes ([ENG-4505](https://linear.app/primeintellect/issue/ENG-4505/model-ui-is-extremely-slow)).
- Fixed provider auth failures leaving stale credentials shown as connected in `/login` ([ENG-4491](https://linear.app/primeintellect/issue/ENG-4491/mark-provider-stale-after-repeated-401s)).
- Fixed typing into the prompt after highlighting an inline subagent ([ENG-4494](https://linear.app/primeintellect/issue/ENG-4494/allow-typing-after-highlighting-a-subagent)).
- Fixed session-targeted heartbeat jobs staying scheduled after sessions are killed or saved sessions are deleted ([#332](https://github.com/PrimeIntellect-ai/prime-agent/pull/332)).
- Fixed self-updates interrupting and automatically resuming daemon sessions instead of waiting for long-running work to finish.
- Fixed provider errors being surfaced instead of retried within the retry budget ([ENG-4503](https://linear.app/primeintellect/issue/ENG-4503/restarting-old-session-returns-empty-model-response)).
- Fixed Agents View returning from fullscreen sessions without flashing primary scrollback ([ENG-4508](https://linear.app/primeintellect/issue/ENG-4508/fullscreen-mode-agents-view-scroll)).

## [0.2.6] - 2026-07-06

- Fixed the installer splash flickering during animation and resize by stabilizing full-screen redraws and removing misleading synthetic percentages ([ENG-4481](https://linear.app/primeintellect/issue/ENG-4481/installer-screen-is-unstable-and-flickery)).
- Fixed Prime Inference auth syncing with Prime CLI login and team selection.
- Fixed provider auth failures showing provider-specific `/login` commands instead of the `/login` selector.
- Removed the legacy pi-mono `bash` and `edit` built-in tools; use IPython `%%bash` cells and the Python `edit` skill instead.

## [0.2.5] - 2026-07-06

- Added daemon-backed user orchestration with agent-to-agent messaging and read-only observation of active sessions ([#207](https://github.com/PrimeIntellect-ai/prime-agent/pull/207) by [@sethkarten](https://github.com/sethkarten)).
- Added an orchestration heartbeat skill for compact multi-session progress, blocker, and action summaries ([#207](https://github.com/PrimeIntellect-ai/prime-agent/pull/207) by [@sethkarten](https://github.com/sethkarten)).
- Added an opt-in auto-refine review hook that can ask whether `/refine` should run after turn intervals or compaction checkpoints ([#201](https://github.com/PrimeIntellect-ai/prime-agent/pull/201) by [@sethkarten](https://github.com/sethkarten)).
- Added opt-in fullscreen mode with a scrollable transcript, pinned prompt bar, mouse selection, and `/fullscreen` controls ([#316](https://github.com/PrimeIntellect-ai/prime-agent/pull/316)).
- Added prompt stashing so a draft can be temporarily saved, a separate prompt or command can run, and the draft is restored afterward ([#321](https://github.com/PrimeIntellect-ai/prime-agent/pull/321)).
- Added resume support to the agents view so stored sessions can be attached and managed without leaving the view ([#318](https://github.com/PrimeIntellect-ai/prime-agent/pull/318)).
- Added subagent delegation guidance to encourage parallel and background `rlm` calls when recursion is available ([#306](https://github.com/PrimeIntellect-ai/prime-agent/pull/306) by [@alexzhang13](https://github.com/alexzhang13)).
- Changed fullscreen TUI rendering to be enabled by default ([#325](https://github.com/PrimeIntellect-ai/prime-agent/pull/325)).
- Changed `--resume` to accept an optional session path or ID ([#319](https://github.com/PrimeIntellect-ai/prime-agent/pull/319)).
- Changed the installer onboarding splash to show ordered setup phases with a percentage instead of cycling detail text ([#327](https://github.com/PrimeIntellect-ai/prime-agent/pull/327), [ENG-4376](https://linear.app/primeintellect/issue/ENG-4376/onboarding-instructions-should-be-accurate-to-whats-happening)).
- Changed provider stream failures to show classified diagnostics and request IDs, with structured agent logs for debugging ([#313](https://github.com/PrimeIntellect-ai/prime-agent/pull/313)).
- Fixed daemon-hosted extensions sharing the wrong Herdr pane environment across concurrent sessions ([#303](https://github.com/PrimeIntellect-ai/prime-agent/pull/303)).
- Fixed parallel subagent guidance failing on first use by pre-importing `asyncio` in the IPython kernel bootstrap ([#315](https://github.com/PrimeIntellect-ai/prime-agent/pull/315)).

## [0.2.4] - 2026-07-01

- Changed the agents view to list only sessions the daemon is actively holding, and stopped the daemon from auto-restoring on-disk sessions on startup, so a restarted daemon no longer surfaces a wall of weeks-old sessions; sessions come back via `/resume` or `--resume` ([#295](https://github.com/PrimeIntellect-ai/prime-agent/issues/295)).
- Changed the kernel install progress line to name the current step and show a percentage instead of a static message ([#293](https://github.com/PrimeIntellect-ai/prime-agent/issues/293)).
- Changed the CLI to honor a `--` end-of-options separator, so arguments after it are passed through instead of parsed as flags ([#296](https://github.com/PrimeIntellect-ai/prime-agent/issues/296)).
- Changed provider stream failures to retry transient errors (content filter trips and prose 5xx responses) instead of failing the turn ([#297](https://github.com/PrimeIntellect-ai/prime-agent/issues/297)).
- Fixed IPython and bash tool calls failing for the rest of a run after a session was rebuilt, by rebinding built-in tools to the live runtime at call time ([#299](https://github.com/PrimeIntellect-ai/prime-agent/issues/299)).
- Fixed the kernel venv not rebuilding when the bundled runtime source changed, by tracking a content hash of the runtime (including its `pyproject.toml`) in the staleness check ([#291](https://github.com/PrimeIntellect-ai/prime-agent/issues/291)).
- Fixed a large subagent fan-out spawning every IPython kernel at once and starving the machine, by bounding concurrent kernel boots (default `min(16, 2*cores)`, override with `PRIME_AGENT_MAX_CONCURRENT_KERNEL_BOOTS`) ([#294](https://github.com/PrimeIntellect-ai/prime-agent/issues/294)).
- Added a Python forkserver (on by default on Linux, opt out with `PRIME_AGENT_KERNEL_FORKSERVER=0`) that forks subagent kernels from one pre-imported template process instead of a full cold boot each time, with automatic fallback to direct spawn on any failure ([#298](https://github.com/PrimeIntellect-ai/prime-agent/issues/298), [#300](https://github.com/PrimeIntellect-ai/prime-agent/issues/300)).
- Fixed empty tool results on OpenAI-style providers being sent as a literal "(see attached image)" placeholder, which made models hallucinate a nonexistent image ([#290](https://github.com/PrimeIntellect-ai/prime-agent/issues/290)).

## [0.2.3] - 2026-06-30

- Added built-in Linear and Notion integrations that the agent drives from Python in the kernel (no new agent tools); each is a bundled skill that talks to the service's official MCP server and auto-discovers its tools. They ship disabled and turn on after you sign in via the Services tab in `/login` or `/mcp login`, with credentials stored in the existing `auth.json` ([#280](https://github.com/PrimeIntellect-ai/prime-agent/issues/280)).
- Added an `attach-image` skill that loads an on-disk image (PNG, JPEG, GIF, WebP) into the model's context as a viewable attachment so a vision-capable model can directly see screenshots, diagrams, charts, or scanned pages ([#274](https://github.com/PrimeIntellect-ai/prime-agent/issues/274)).
- Changed subagents to be first-class sessions: opening a subagent now attaches to its own session and renders through the same rich chat UI as the main conversation instead of a laggy parent-rebuilt transcript, finished subagents stay viewable in the list and sort below running ones, and the detail view shows the subagent's own recap and animated working status ([#282](https://github.com/PrimeIntellect-ai/prime-agent/issues/282)).
- Changed session lifecycle handling so the agents view now lists every live session (not only daemon-resident ones), fixing reports of sessions going missing; abandoned new chats that were never sent a message are discarded instead of lingering ([#269](https://github.com/PrimeIntellect-ai/prime-agent/issues/269)).
- Changed the IPython kernel to stay alive across compaction: variables, imports, and helpers the agent defined are no longer wiped, and the model is instead told which names remain defined ([#267](https://github.com/PrimeIntellect-ai/prime-agent/issues/267)).
- Changed local slash commands like `/context`, `/system-prompt`, `/logs`, `/changelog`, and `/hotkeys` to echo the typed command into the chat so their output is anchored to a visible command instead of floating ([#270](https://github.com/PrimeIntellect-ai/prime-agent/issues/270)).
- Changed session recaps to use a non-reasoning model (Qwen3-30B instruct), which reliably closes the recap tag instead of occasionally surfacing a dangling "..." ([#284](https://github.com/PrimeIntellect-ai/prime-agent/issues/284)).
- Changed the heartbeat scheduler to defer `/heartbeat` and internal heartbeat cron jobs while the target session is already working, rescheduling the next interval instead of piling a prompt onto a busy agent ([#265](https://github.com/PrimeIntellect-ai/prime-agent/issues/265)).
- Changed `Ctrl+O` on IPython and bash cells to keep the same summary line in place and just attach the full code and output beneath it (aligned under the code gutter), instead of restructuring the block on expand ([#288](https://github.com/PrimeIntellect-ai/prime-agent/issues/288)).
- Removed the "call at most one built-in tool per turn" instruction from the system prompt, allowing the agent to invoke multiple built-in tools in a single turn ([#210](https://github.com/PrimeIntellect-ai/prime-agent/issues/210)).
- Fixed historical session replay re-emitting inline terminal image escape payloads; history now shows lightweight image fallback labels while live tool results still render images inline ([#281](https://github.com/PrimeIntellect-ai/prime-agent/issues/281)).
- Fixed pressing back from a subagent opened directly from the agents view dropping you into the parent's chat; it now returns to the agents view, with a "back to agents" hint ([#271](https://github.com/PrimeIntellect-ai/prime-agent/issues/271)).
- Fixed the agents view resetting the highlight to the first row when returning to it; selection now sticks to the session you had open across reorders and reattaches ([#268](https://github.com/PrimeIntellect-ai/prime-agent/issues/268)).
- Fixed freshly created chats being titled by their session ID until their file flushed; they are now titled by their first prompt immediately ([#264](https://github.com/PrimeIntellect-ai/prime-agent/issues/264)).
- Fixed opening a session from the agents view failing when its original working directory no longer exists; it now opens in a fallback directory with a notice instead of breaking ([#287](https://github.com/PrimeIntellect-ai/prime-agent/issues/287)).

## [0.2.2] - 2026-06-25

- Added a bundled `websearch` skill (Google search via the Serper API) that loads by default. Add a Serper key via `/login` ("Serper (web search)"); it is stored with your other credentials and supplied to the skill automatically. The skill can be disabled with `bundledSkills.websearch: false` and overridden by a same-named skill in any user, project, package, or `--skill` location ([#86](https://github.com/PrimeIntellect-ai/prime-agent/issues/86)).
- Added image input support for vision-capable Prime Inference models (Claude, GPT-5.x, Grok, Kimi K2.7 Code, Qwen3-VL), which previously dropped attached images as unsupported ([#261](https://github.com/PrimeIntellect-ai/prime-agent/issues/261)).
- Added a live subagent tree above the working loader showing each in-flight subagent with a prompt excerpt, tool-use and token counts, and its recap once generated; finished subagents drop out of the tree ([#254](https://github.com/PrimeIntellect-ai/prime-agent/issues/254)).
- Changed the prompt bar to show the active model and thinking level on the left and always show context token count and percentage used on the right, instead of only surfacing context usage past the halfway point ([#252](https://github.com/PrimeIntellect-ai/prime-agent/issues/252)).
- Changed the `/model` picker to rank results by most-recently-used, so models you actually pick float to the top and break ties among equally-good fuzzy matches ([#251](https://github.com/PrimeIntellect-ai/prime-agent/issues/251)).
- Changed the collapsed bash and IPython tool previews to pick the most informative line via a shared heuristic, skipping low-signal setup lines and redacting long blobs and secret-looking values ([#248](https://github.com/PrimeIntellect-ai/prime-agent/issues/248)).
- Changed subagents to render as an inline, scrollable list below the prompt with arrow-key navigation and prompts that elide shared prefixes, replacing the full-screen subagent viewer; running subagents and in-progress markers now animate so the agent never looks crashed ([#247](https://github.com/PrimeIntellect-ai/prime-agent/issues/247)).
- Fixed context overflow appearing at ~50% remaining for Prime Inference Claude models by correcting their context window to 200k and counting prompt tokens only (excluding output) for the context indicator and compaction trigger ([#246](https://github.com/PrimeIntellect-ai/prime-agent/issues/246)).

## [0.2.1] - 2026-06-23

### Fixed

- Fixed daemon session recaps disappearing while a new turn regenerated them ([#239](https://github.com/PrimeIntellect-ai/prime-agent/issues/239)).
- Fixed bundled built-in skills missing from the packaged release layouts ([#240](https://github.com/PrimeIntellect-ai/prime-agent/issues/240)).

## [0.2.0] - 2026-06-23

### Added

- Added `/effort` (alias `/thinking`) to set the reasoning level, with argument autocomplete that lists the levels the current model supports.
- Added a `/system-prompt` command that shows the exact prompt last sent to the model, labelling it honestly when no turn has run yet.
- Added a `/rename` alias for `/name` and a `Ctrl+R` shortcut in the Agents View to rename the selected session inline.
- Added support for feeding pasted images into model context: pasted images become atomic editor markers, are validated and resized, held in a bounded registry, and dropped when the active model lacks vision.
- Added edit diffs to the collapsed IPython view, rendering file edits as a wrapped, full-width relative-path diff prefixed with the cell status marker.

### Changed

- Replaced the `Shift+Tab` thinking-level cycle with the `/effort` command, exposing a `max` thinking level on Claude models that support it.
- Changed the `/goal` and `/effort` commands to stay highlighted in the editor while their argument is being typed.
- Changed queued follow-up messages to render below the execution indicator.
- Changed the RLM system prompt to align its shared sections exactly with rlm-harness, including the environment block and pre-installed package hints.
- Changed trace uploads to be observable and resilient: failures surface the underlying cause, outcomes are logged to `agent-traces.log`, `/traces` shows the resolved endpoint, and transient failures retry once.

### Fixed

- Fixed Prime Agent formatting breaking when resizing to a small screen, where tool-output colors bled into the padding at narrow widths.
- Fixed onboarding showing no models after entering a provider key by refreshing the scoped model list after login.
- Fixed silent daemon replacement reading as random crashes by logging shutdown/replacement decisions, and offering to stop a stale-version daemon at startup instead of erroring out.

### Performance

- Improved session load, context building, and listing to scale linearly: file loads decode per line over a raw buffer, and branch/context building uses push+reverse instead of per-entry unshift.
- Improved daemon responsiveness under large session loads by parsing session files off the event loop, so loading one big session no longer freezes the other sessions the daemon hosts.

## [0.1.9] - 2026-06-22

### Added

- Added the Prime brand splash to the new-chat view.

### Changed

- Changed daemon attach to send slimmer snapshots and to avoid saved-session disk scans in the Agents View, speeding up switching between sessions.

### Fixed

- Fixed daemon out-of-memory crashes when listing saved sessions by streaming the listing, preserving large session row metadata, and ignoring oversized tool rows when computing session activity.

## [0.1.8] - 2026-06-21

### Added

- Added `daemon shutdown --all` to stop every Prime Agent daemon on the machine, hardened against recycled PIDs and able to force-kill wedged daemons.
- Added git context to session traces: each trace records the repository URL, branch ref, and HEAD commit, captured at end of turn and carried over when a session is forked.

### Changed

- Changed `prime-agent` to open a new chat by default at launch instead of the previous session, with the daemon session created lazily on the first message and empty chats discarded on quit.
- Changed sending a message from the Agents View to open the chat for that session.
- Changed model resolution to persist the selected model across updates and default Prime Inference to Claude Opus 4.8 when no model has been chosen.

### Fixed

- Fixed `prime-agent` attaching to a stale daemon left running by a previous version after self-update: `update` now stops the old daemon and starts the new version (confirming first when busy sessions would lose work), and a stale daemon that cannot be replaced fails loudly instead of a silent broken attach. Both shutdown paths now poll the socket until it stops listening, so a transient hiccup cannot spawn a duplicate daemon.

## [0.1.7] - 2026-06-18

### Added

- Added session and RLM heartbeats: a persistent, user-controlled heartbeat re-prompts a long-running session on a schedule via daemon-backed cron jobs, exposed through the `heartbeat` slash command and a bundled `rlm-heartbeat` Python skill, plus a `cron` CLI command to list jobs.

### Changed

- Changed collapsed IPython tool calls in the TUI to render as a single-line summary instead of a multi-line block.

## [0.1.6] - 2026-06-17

### Added

- Added a `daemon ps` CLI command that lists every Prime Agent daemon running on the machine, with confirmation before shutdown and guards against killing a shared or still-reachable daemon.
- Added opt-in trace uploads: `/traces` enables background upload of persisted session JSONL files to the Prime Inference trace endpoint.
- Added agent summaries and live status to Agents View, generated daemon-side per session and refreshed on sweep.
- Added crash-stack capture for the daemon: output routes to a rotating per-socket log file under `<agentDir>/logs/`, client-side crashes write to `client-errors.log`, and a `/logs` command shows the log directory.

### Changed

- Changed startup notices (app-update, extension-update, and tmux warnings) to surface on the Agents View instead of being appended to every chat session.

### Fixed

- Fixed IPython kernel state being lost across session resume: kernel variables are now snapshotted under session-artifacts, restored on resume, deleted with the session, and dropped on compaction.
- Fixed the viewport jumping when toggling tool-output expansion in the TUI; the viewport now stays anchored across expand/collapse.
- Fixed non-persisted (e.g. `/tmp`) sessions creating an RLM working directory they did not need.

## [0.1.5] - 2026-06-16

### Added

- Added rich syntax-aware diff rendering for IPython file edits in the TUI: the `edit` Python skill emits structured edit results that the interactive view renders as a colored, full-width unified diff inside the cell.
- Added a subagent spawn-program panel to Agents View: expand a subagent group and press `Ctrl+O` to toggle a panel showing the IPython cell that called `rlm.run` to spawn them.
- Added slash-command alias resolution so command aliases resolve to their canonical command consistently across interactive mode and Agents View, including in autocomplete.

### Changed

- Moved goals out of the harness tool surface into a bundled `goal` Python skill (`goal.get` / `goal.create` / `goal.complete`) backed by session state; the only built-in tool is now `ipython`, and the `rlm.run` comm channel is generalized into a typed host bridge.
- Changed the RLM system prompt to prefer Python for reading and searching files, porting the IPython guidance from rlm-harness.
- Spaced out the Agents View shortcut hints for readability.

### Fixed

- Fixed slow opening of long agent sessions: the JSONL socket reader is now O(n) instead of O(n^2) on large records, the session tree is fetched lazily instead of embedded in the attach snapshot, `SessionManager.open()` no longer parses the session file twice, and context building avoids copying every entry on the hot path.
- Fixed `open()` to stay consistent with the full loader when a session file begins with a blank line.
- Fixed goal-completion usage accounting that could overcount tokens.

## [0.1.4] - 2026-06-15

### Added

- Added a `/refine` command and a session-backed `rlm.harness` continual-learning state (prompt notes, memory, reusable skills, and subagent specs) that persists globally across sessions, with explicit CRUD methods, a refinement log, and global rollback. The compact harness overview is injected into the system prompt, and `/refine` re-reads state before applying so concurrent writes are not clobbered.
- Added an `edit` built-in Python RLM skill for targeted single-occurrence string replacement in existing files, callable from the kernel or as a shell command.

### Changed

- Changed the IPython control prompt to require `%%bash` as the first line of a shell cell to match the rlm-harness.

## [0.1.3] - 2026-06-12

### Added

- Added a `/context` command showing a tree overview of the main agent and all sub-agents with per-agent tokens, cost, and context-window usage, plus session totals and a token/cost breakdown.
- Added `/clear` as an alias for `/new`.

### Changed

- Changed `/usage` to be an alias for the new `/context` command.

### Fixed

- Fixed the stale "no models available" warning appearing for sessions that already have a working model.
- Fixed the `!` and `!!` bash shortcuts in interactive mode by running bash through the agent connection, restoring streaming output, history, and Ctrl+C abort for both in-process and daemon-attached clients.

## [0.1.2] - 2026-06-12

### Fixed

- Fixed the model selector showing no models after logging in with Prime Inference during onboarding by reloading auth storage from disk when the model registry refreshes ([#151](https://github.com/PrimeIntellect-ai/prime-agent/issues/151)).

## [0.1.1] - 2026-06-11

### Fixed

- Fixed first launch to run onboarding before opening the Agents View ([#147](https://github.com/PrimeIntellect-ai/prime-agent/issues/147)).
- Fixed multiline status errors in Agents View to render as a single flattened line so they cannot overlap the input ([#146](https://github.com/PrimeIntellect-ai/prime-agent/issues/146)).
- Fixed slash commands in the main Agents View ([#149](https://github.com/PrimeIntellect-ai/prime-agent/issues/149)).

## [0.1.0] - 2026-06-11

### Breaking Changes

- Changed `InteractiveMode` construction to require an `AgentConnection` and explicit UI services or local session host.

### Added

- Added a two-step `Ctrl+X` stop/delete interaction for selected agents in Agents View.
- Added a daemon-backed Agents View as the default local interactive entrypoint.
- Added versioned daemon protocol metadata, sequenced session events, attach snapshots, replay status, and artifact references for future Swarm gateway wrapping.
- Added an `AgentConnection` client boundary with in-process and daemon adapters for interactive-mode decoupling.
- Added daemon mode and CLI controls for starting on demand, creating, listing, attaching, detaching, killing, renaming, and prompting live sessions.
- Added rich TUI attach for already-active daemon sessions via `--session <selector>` and live `daemon <selector>` shorthand.
- Added a built-in `skill-creator` skill that teaches the agent to create new skills: markdown layout, frontmatter rules, placement and precedence, and the Python-backed skill contract (package layout, `run()` convention, optional CLI, kernel venv behavior) with a test-verified working template.
- Added built-in skills shipped with prime-agent, starting with `prime-intellect`: ecosystem knowledge and prime CLI workflows for verifiers environments, evaluations, Hosted Training, sandboxes, inference, and compute. Built-in skills have the lowest precedence (user, project, and package skills with the same name win) and can be disabled with the `enableBuiltinSkills` setting or `--no-skills`.
- Added a session-backed `rlm.harness` state helper for reset-free prompt notes, memory, skills, subagent specs, and refinement events.
- Added `/refine` to update editable harness state with Create/Update/Delete edits and rollback support based on refinement history.

### Changed

- Changed Agents View `Ctrl+C` handling to mirror the interactive chat view: the first press shows a bottom hint and the second exits Prime Agent.
- Changed keybinding hints to render arrow keys as `↑`, `↓`, `←`, and `→`.
- Changed Agents View to keep transient status and reply text out of the agent list area.
- Changed Agents View `Ctrl+X` so the first press only stops sessions that are actively running.
- Changed daemon-owned chat sessions opened from Agents View to show a `← agents` tray hint when the input is empty.
- Changed active session creation to use per-session runtime config so active sessions can use different cwd, model, auth, and tool settings.
- Changed interactive `Ctrl+C` to interrupt the current operation first and exit only on a second press while the exit hint is visible; `Escape` now clears the input bar without interrupting the agent.
- Changed the IPython system prompt section to use the upstream rlm-harness IPYTHON_CONTROL_PROMPT: IPython is framed as a persistent control environment, not the target project's runtime. Shell commands should use `%%bash` cells instead of `!cmd` escapes. The agent should not install dependencies into the IPython kernel but use the project's own environment instead.
- Removed the `.venv` interpreter hint from the system prompt (no longer needed with the control-environment framing).

### Fixed

- Fixed confusing transcript formatting around thinking blocks and tool calls: ipython cells and default-shell tools (bash and extension tools) now share one panel style with a subtle neutral background instead of a status-colored box or a left rail, and tool status headers name the tool (`python · done · 7ms`, `bash · running`) so they no longer read as floating labels for the preceding thinking block. Themes gain a required `toolPanelBg` color for the panel background.
- Fixed `prime-agent` to detect a daemon left running by a previous version after self-update: the daemon now reports its app version on connect, and idle stale daemons are restarted automatically (daemons with active sessions are left running with a warning).
- Fixed Agents View listing daemon-owned subagents as top-level selectable agents instead of nested child rows.
- Fixed Agents View opening saved or stale sessions by creating a daemon runtime from the saved session file before attaching.
- Fixed Agents View delete confirmation so the red stopped confirmation expires after two seconds without removing the stopped session row.
- Fixed Agents View selected-row highlighting so it spans the full terminal width after prompt wrapping changes the layout.
- Fixed Agents View prompt bar to show a placeholder for creating a new session.
- Fixed Agents View opening sessions with the dashboard cwd's model registry, which could incorrectly show the model selector for daemon-owned sessions from another cwd.
- Stopped showing changelog entries automatically on install, first launch, and update startup.
- Fixed multi-line IPython, assistant, and child-agent errors to collapse internal tracebacks by default while preserving full details on expand.
- Fixed child-agent navigation to show contextual keybinding hints and a visible focused tray marker.
- Fixed the release installer to ask before bootstrapping the IPython kernel runtime during install, avoiding default first-run `uv` prompts inside the TUI.
- Fixed browser sign-in links to show plain URLs when terminal hyperlinks are unsupported.
- Fixed the release installer splash to keep its logo geometry stable across terminal resizes.

### Removed

- Removed the interactive `!` / `!!` bash shortcuts; use IPython for shell commands.

## [0.0.10] - 2026-06-08

### Added

- Added an inline input prompt indicator to the interactive editor.
- Added contextual keybinding hints and a visible focused tray marker for child-agent navigation.
- Added OS-specific shortcut labels in keybinding hints, rendering `Cmd`/`Option` on macOS and capitalized key names elsewhere.

### Changed

- Changed the IPython system prompt to the upstream rlm-harness `IPYTHON_CONTROL_PROMPT`: IPython is framed as a persistent control environment rather than the target project's runtime, shell commands use `%%bash` cells instead of `!cmd`, and project imports, tests, and dependency checks run through the project's own environment. Removed the `.venv` interpreter hint.
- Changed interactive `Ctrl+C` to interrupt the current operation first and exit only on a second press while the exit hint is visible; `Escape` now clears the input bar without interrupting the agent.
- Changed the Prime theme to tone down the flashy neon purple and lime green in favor of a calmer dusty lavender and sage green.

### Fixed

- Fixed missing ripgrep to surface a clean inline warning at startup and fail sub-agent runs with a clear message, while routing kernel diagnostics into captured stderr.
- Fixed IPython kernel startup to avoid blocking the session, cancelling child RLM runs on session abort and reporting bootstrap progress through a start-options handler.
- Fixed the subagent tool-expansion keybinding so it toggles expanded tool output inside the child-agent detail view.
- Fixed browser sign-in links to show plain URLs when the terminal does not support hyperlinks.
- Fixed the auth selector to preserve the selected provider's login type.
- Stopped showing changelog entries automatically on install, first launch, and update startup.

## [0.0.9] - 2026-06-04

## [0.0.8] - 2026-06-04

### Added

- Added an `onboardingCompleted` setting and a dedicated Prime Inference onboarding splash that prompts users authenticated only via the Prime CLI to choose a model before their first turn.

### Changed

- Changed the system prompt to frame the agent as a general-purpose agent that uses code to solve tasks rather than a pure coding agent, with guidance that shell state does not persist across `!cmd`/`%%bash` cells while Python kernel state does.

### Fixed

- Fixed the onboarding flow so model selection, manual API-key entry, cancellation, and the "model already ready" path all resolve correctly and mark onboarding complete instead of re-prompting on every launch.
- Fixed the release installer to ask before bootstrapping the IPython kernel runtime during install (defaulting to bootstrap when no terminal is detected) and to avoid stalling on an interactive `uv` prompt.

## [0.0.7] - 2026-06-01

### Added

- Added Prime team selection during Prime Inference login so team inference costs use the selected Prime CLI context.
- Added Python-backed skills that install into the persistent IPython kernel and are exposed alongside markdown skills.

### Changed

- Changed the Prime Agent install script to use a bounded animated Prime Lab splash with centered progress and confirmation prompts.
- Changed startup onboarding to guide unauthenticated users through login and model selection before the first agent turn.
- Changed installer npm and Node.js setup progress to keep command output hidden behind the splash and rotate detail text.

### Fixed

- Fixed update notifications and package docs to point at `prime-agent update` and use compact one-line alerts.
- Fixed Prime CLI credentials from `prime login` to make Prime Inference models available on startup.
- Fixed first-run search helper downloads to run quietly instead of printing over onboarding.
- Fixed stale no-model and tmux/update startup notices from appearing during successful onboarding.

### Removed

- Removed the unused small Prime logo export.

## [0.0.6] - 2026-05-27

### Changed

- Changed installer startup so npm and Node.js setup output stays hidden behind the bounded Prime splash with rotating detail text.
- Changed `postinstall` to optionally bootstrap the `fd` and `rg` search helpers (gated by an env flag) alongside the kernel, and made search-helper downloads default to silent.

### Fixed

- Fixed Prime Inference auth so credentials from `prime login` are read from the Prime CLI config and surfaced as a `prime_cli` auth source, making Prime Inference models available on startup without a separate login.
- Fixed initial model selection to skip a saved default model that no longer has configured auth.
- Fixed first-run search-helper downloads to run quietly instead of printing over onboarding.

## [0.0.5] - 2026-05-26

### Added

- Added a centered-overlay menu system for onboarding and a redesigned Prime onboarding splash and Prime Inference login dialog with browser sign-in plus a manual API-key fallback.
- Added theme support for adapting interactive surfaces to the detected terminal foreground/background colors.

### Changed

- Changed startup onboarding to guide unauthenticated users through login and model selection before the first agent turn.
- Changed the model selector and OAuth/provider selectors to render as centered surface menus rather than inline CLI lists.
- Changed update and package-update notifications to compact one-line alerts pointing at `prime-agent update`.

## [0.0.4] - 2026-05-21

### Added

- Added system prompt note listing pre-installed Python packages (requests, httpx, pyyaml, tomli, python-dotenv, pandas, numpy, scipy, beautifulsoup4, lxml, pydantic).
- Added `DEFAULT_RLM_EXTRA_UV_ARGS` constant and kernel bootstrap installation of those packages; updated prompt to reference the constant instead of a hardcoded list.

### Fixed

- Fixed the RLM kernel package prompt to show importable module names and reject `PRIME_AGENT_KERNEL_PYTHON` overrides missing default kernel packages.

## [0.0.2] - 2026-05-20

### Added

- Added a persistent `ipython` tool backed by a Jupyter kernel so Python variables and imports survive across tool calls.
- Added the RLM harness system prompt and `prime-agent-runtime` bridge so IPython code can call `rlm.run` to spawn recursive child agent sessions.
- Added automatic IPython runtime bootstrap with uv-managed Python, `ipykernel`, and `prime-agent-runtime`.
- Added subagent UI surfaces for recursive runs, including compact tray status, full-width detail views, and structured child transcripts rendered like the main chat.
- Added `/goal` for long-running objectives that continue after normal follow-ups drain until the model marks the goal complete.
- Added a pi-style installer script and R2-backed private npm tarball release pipeline for Prime Agent.
- Added Prime Inference as a selectable built-in OpenAI-compatible provider with `PRIME_API_KEY` authentication and `openai/gpt-5.5` as the default model.
- Added a first-class `/login` Prime Inference browser auth flow that imports usable Prime CLI credentials or obtains a new key through the Prime challenge flow.
- Added `/usage` to show token, cost, and context usage on demand.

### Changed

- Changed the default active built-in tool set to `ipython`.
- Changed compaction to restart the active IPython kernel so summarized sessions release in-memory Python state.
- Changed recursive background work to use normal Python async tasks with `rlm.run` instead of a separate RLM background API.
- Changed completed IPython cell rendering to use width/version-aware caching, reducing TUI redraw lag in long sessions.
- Changed collapsed IPython cells to show compact input and output previews with a single expansion hint.
- Changed auto-compaction checks to use the current context estimate and stop between long tool-loop turns before resuming after compaction.
- Changed the goal status UI to use a compact lower-tray indicator instead of repeating the full objective in chat.
- Changed IPython prompt guidance to prefer `!cmd` and `%%bash` for shell commands.
- Changed kernel bootstrap to prompt before installing `uv` and skip postinstall bootstrap unless explicitly enabled.
- Changed the app update check and self-update flow to read the Prime Agent release manifest and install manifest tarballs directly.

### Fixed

- Fixed tarball self-updates to install the tarball without first uninstalling the same logical package.
- Fixed IPython kernel startup to let `ipykernel` bind OS-assigned ports instead of randomly selecting fixed ports.
- Fixed RLM child usage aggregation so parent session totals include recursive child runs after session reloads.
- Fixed the RLM child-agent detail viewer to render messages, thinking, and tool output with the main chat presentation, open at the latest transcript output, and use terminal scrollback for native scrolling.
- Fixed `rlm.run` comm handlers to log failures and drain in-flight child runs during kernel disposal.
- Fixed raw tab rendering in TUI-backed transcript views so painted backgrounds survive indentation.
- Fixed auto-compaction threshold checks during trailing context and tool-result growth.

### Removed

- Removed install/update telemetry pings to `pi.dev` and the related setting and environment override.
- Removed the RLM background API; recursive agents now use `rlm()`/`rlm.run()` with normal Python async tasks for background work.
- Removed the legacy `read`, `write`, `grep`, `find`, and `ls` built-in tools.
- Removed the local TPS extension that posted token/cache stats after each agent response.

## [0.0.1] - 2026-05-18

### Added

- Initial Prime Agent release, forked from pi-mono: a persistent `ipython` tool backed by a Jupyter kernel as the default tool set, recursive RLM subagents via `rlm.run`, `/goal` for long-running objectives, an auto-bootstrapped uv-managed kernel runtime, Prime-branded TUI, and an R2-backed tarball release pipeline with a pi-style installer.
